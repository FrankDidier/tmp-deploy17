define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'subarea.goods/index' + location.search,
                    add_url: 'subarea.goods/add',
                    edit_url: 'subarea.goods/edit',
                    del_url: 'subarea.goods/del',
                    multi_url: 'subarea.goods/multi',
                    import_url: 'subarea.goods/import',
                    table: 'subarea_goods',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                sortOrder: 'desc',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'mobile', title: '手机号', operate: false},
                        {field: 'subarea_name', title: '场次名称', operate: false},
                        {field: 'goods_name', title: '商品名称', operate: false},
                        {field: 'price', title: '商品价格', operate:'BETWEEN'},
                        {field: 'cover_image', title: '封面图', operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'carousel_image', title: '轮播图', operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'status', title: '状态', searchList: {"0":'停用',"1":'启用'}, formatter: Table.api.formatter.status},
                        {field: 'createtime', title: '创建时间', operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate,
                            buttons: [
                                {name: 'assign', text: '指派用户', title: '指派用户', classname: 'btn btn-xs btn-success btn-assignuser', icon: 'fa fa-user'}
                            ],
                            formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            // 指派用户：使用 selectpage 下拉（服务端分页显示全部会员 + 手机号/昵称模糊搜索 + 点击选中）
            $(document).on('click', '.btn-assignuser', function () {
                var data = table.bootstrapTable('getData');
                var index = $(this).parents('tr').data('index');
                var row = data[index];
                if (!row) { Toastr.error('未获取到商品'); return; }
                var html = '<form role="form" style="padding:20px;">'
                    + '<div style="margin-bottom:10px;color:#666;">商品：' + (row.goods_id ? ('#' + row.goods_id) : '') + '　价格：¥' + (row.price || 0) + '</div>'
                    + '<label>指派所属用户（可输入手机号/昵称搜索）：</label>'
                    + '<input id="assign-user-select" class="form-control selectpage" '
                    + 'data-source="user/user/index" data-primary-key="id" data-field="nickname" '
                    + 'data-search-field="nickname,username,mobile" data-format-item="{nickname} - {mobile}" '
                    + 'data-pagination="true" data-page-size="20" '
                    + 'style="width:100%;margin-top:8px;" type="text" value="">'
                    + '</form>';
                Layer.open({
                    type: 1, title: '指派所属用户', area: ['460px', '260px'], content: html,
                    success: function (layero) {
                        // 初始化 selectpage（读取 data-* 属性，走 user/user/index 接口，支持手机号模糊搜索与翻页显示全部）
                        Form.events.selectpage($('form', layero));
                    },
                    btn: ['提交', '取消'],
                    yes: function (idx) {
                        // selectpage 选中的主键存放在同容器内的隐藏域(.sp_hidden)
                        var uid = $('#assign-user-select').closest('.sp_container').find('.sp_hidden').val();
                        if (!uid) { Toastr.error('请选择用户'); return; }
                        $.ajax({
                            url: 'subarea.goods/assignuser', type: 'post', dataType: 'json',
                            data: {ids: row.id, user_id: uid},
                            success: function (r) {
                                if (r.code === 1) { Toastr.success(r.msg); Layer.close(idx); table.bootstrapTable('refresh'); }
                                else { Toastr.error(r.msg || '指派失败'); }
                            },
                            error: function () { Toastr.error('请求失败'); }
                        });
                    }
                });
            });
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});

#!/bin/bash
# 2026-07-21 更新：抢购订单「指派」改为与商品列表一致的可搜索会员下拉（可重新指派）
ROOT=${1:-/www/wwwroot/mall.feiyunkeji.cn}
PKG=$(cd "$(dirname "$0")" && pwd)
LOG=$ROOT/deploy_update.log
exec >"$LOG" 2>&1
echo "=== DEPLOY START $(date) ==="
echo "PKG=$PKG ROOT=$ROOT"
find "$PKG" -name '._*' -delete 2>/dev/null || true
find "$PKG" -name '.DS_Store' -delete 2>/dev/null || true
cp -rf "$PKG/backend/application/." "$ROOT/application/" && echo "-- application copied"
cp -rf "$PKG/backend/public/." "$ROOT/public/" && echo "-- public assets copied"
find "$ROOT/application" "$ROOT/public/assets/js/backend" -name '._*' -delete 2>/dev/null || true
rm -rf "$ROOT/runtime/cache/"* "$ROOT/runtime/temp/"* 2>/dev/null || true
echo "-- runtime cache cleared"
echo "DEPLOY_OK $(date)"

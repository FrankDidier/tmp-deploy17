#!/bin/bash
# 2026-07-20 更新部署（宝塔计划任务执行）
# 本轮改动：
#   后端 application：Subarea(结算/本场购入立即显示、pay_kind null、getSettlement 对齐)、
#     Order(待支付靠前、取消订单 cancel)、TeamService(粉丝按pid直推)、
#     user/User(抢购次数只算当日)、subarea/Goods(指派防重行锁)
#   后端 public/assets/js：order.js(取消订单按钮)、subarea/goods.js(指派防连点)
#   前端 H5：抢购页每页20条+≈x盒(price/5978)+抢完消失、page_size=10000、结算页按order_id配对
# 无需数据库迁移。
# 用法：bash deploy.sh [webroot]   默认 mall.feiyunkeji.cn；mall3 传入其站点根目录。
ROOT=${1:-/www/wwwroot/mall.feiyunkeji.cn}
PKG=$(cd "$(dirname "$0")" && pwd)
LOG=$ROOT/deploy_update.log

exec >"$LOG" 2>&1
echo "=== DEPLOY START $(date) ==="
echo "PKG=$PKG ROOT=$ROOT"

# 0) 先清理 macOS 隐藏文件，避免 ThinkPHP 误 include 导致白屏/乱码
find "$PKG" -name '._*' -delete 2>/dev/null || true
find "$PKG" -name '.DS_Store' -delete 2>/dev/null || true

# 1) 后端 application（控制器/服务）
cp -rf "$PKG/backend/application/." "$ROOT/application/" && echo "-- application copied"

# 2) 后台静态资源 js（order.js / subarea/goods.js）
cp -rf "$PKG/backend/public/." "$ROOT/public/" && echo "-- public assets copied"

# 3) H5（重新编译）
mkdir -p "$ROOT/public/h5"
find "$ROOT/public/h5" -mindepth 1 -delete 2>/dev/null || true
cp -rf "$PKG/h5/." "$ROOT/public/h5/" && echo "-- h5 deployed to public/h5"

# 4) 再次清理隐藏文件（部署目标目录）
find "$ROOT/application" "$ROOT/public/h5" "$ROOT/public/assets/js/backend" -name '._*' -delete 2>/dev/null || true

# 5) 清理 ThinkPHP 缓存
rm -rf "$ROOT/runtime/cache/"* "$ROOT/runtime/temp/"* 2>/dev/null || true
echo "-- runtime cache cleared"

echo "DEPLOY_OK $(date)"

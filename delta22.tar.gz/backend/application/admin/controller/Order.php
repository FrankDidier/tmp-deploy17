<?php

namespace app\admin\controller;

use app\common\controller\Backend;
use app\common\library\OrderService;
use think\Db;
use think\Exception;

/**
 * 订单
 *
 * @icon fa fa-circle-o
 */
class Order extends Backend
{

    /**
     * Order模型对象
     * @var \app\admin\model\Order
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\Order;
        $this->view->assign("typeList", $this->model->getTypeList());
        $this->view->assign("payTypeList", $this->model->getPayTypeList());
        $this->view->assign("payStatusList", $this->model->getPayStatusList());
    }

    /**
     * 订单列表（关联商品/买家/卖家/场次，1:1 对齐示例站列表字段）
     */
    public function index()
    {
        if ($this->request->isAjax()) {
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            // 经济参数全部动态读取后台配置（交易利益比/手续费）
            $increaseFee = (float) Db::name('config')->where('name', 'increaseFee')->value('value');
            $listingFee  = (float) Db::name('config')->where('name', 'listingFee')->value('value');
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $list = $this->model
                ->with(['goods', 'buyer', 'seller', 'subarea', 'warehouse'])
                ->where($where)
                ->where('pay_kind', '<>', 2) // 排除「上架费付款」单，抢购订单只展示商品交易订单
                // 待支付(pay_status=0)靠前显示（对照甲方：待支付状态订单需要靠前）
                ->order('pay_status', 'asc')
                ->order($sort, $order)
                ->paginate($limit);
            foreach ($list as $row) {
                $row->getRelation('goods')     && $row->goods->visible(['name', 'image']);
                $row->getRelation('buyer')     && $row->buyer->visible(['nickname', 'username', 'mobile']);
                $row->getRelation('seller')    && $row->seller->visible(['nickname', 'username', 'mobile']);
                $row->getRelation('subarea')   && $row->subarea->visible(['name']);
                $row->getRelation('warehouse') && $row->warehouse->visible(['buy_price', 'sell_price']);
                // 买价 = 本单「成交价(买家实付 = order.amount)」。
                //   场景：A 以 1000 抢入再 1030 挂售，B 以 1030 抢入 → 本单买价应为 1030（B 实付），
                //   不能再显示卖家 A 的历史成本 1000（对照甲方反馈：挂售后再抢购，买价应为挂售价）。
                $buyPrice = (float) $row->amount;
                // 收益 = 成交价 *（交易利益比% − 手续费%）（甲方公式：1030*1.3%=13.39）
                //   3% 溢价中：1.3% 为卖家净利润，1.7% 为服务费(0.4%直推奖+1.3%上架费)
                $row->profit = $buyPrice > 0 ? round($buyPrice * ($increaseFee - $listingFee) / 100, 2) : 0;
                // 卖价 = 成交价 *（1 + 交易利益比%）（买家后续转售价，对照示例站）
                $row->sell_price = $buyPrice > 0 ? round($buyPrice * (1 + $increaseFee / 100), 2) : (float) $row->amount;
                // 买价列直接用成交价展示（前端列 field=buy_price）
                $row->buy_price = $buyPrice;
                // 是否已上架进抢购池：关联仓库处于「委卖中(2)/抢购锁定(4)」→ 前端隐藏「指派」按钮
                //   （对照甲方：批量上架之后，这个指派就应该没有了）
                $wh = $row->getRelation('warehouse');
                $row->listed = ($wh && in_array((int) $wh->status, [2, 4], true)) ? 1 : 0;
            }
            $result = ['total' => $list->total(), 'rows' => $list->items()];
            return json($result);
        }
        return $this->view->fetch();
    }


    /**
     * 删除订单：同时级联清理「仍在委卖中(status=2，未成交)」的关联仓库记录，
     * 避免删除抢购订单后前端抢购板仍显示该商品（对照用户反馈：删了订单前端还显示）。
     * 已成交/持有(status=1/3/4) 的仓库不动，避免破坏会员持仓与历史成交。
     */
    public function del($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__('Invalid parameters'));
        }
        $ids = $ids ?: $this->request->post('ids');
        if (!$ids) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', (string) $ids);
        Db::startTrans();
        try {
            $whIds = Db::name('order')->whereIn('id', $idArr)->where('warehouse_id', '>', 0)->column('warehouse_id');
            if ($whIds) {
                // 删除抢购订单时，把「委卖中(2，未成交)」的关联仓库退回「持有(1)」——移出前端抢购板，
                //   但保留会员持仓，便于后续再次批量上架/指派会重新生成抢购订单。
                //   (对照甲方反馈：批量上架→删除后→再上架应仍能生成新抢购订单，不能把商品删没了)
                Db::name('warehouse')->whereIn('id', $whIds)->where('status', 2)
                    ->update(['status' => 1, 'updatetime' => time()]);
            }
            $count = $this->model->where('id', 'in', $idArr)->delete();
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('删除失败：' . $e->getMessage());
        }
        if ($count) {
            $this->success();
        }
        $this->error(__('No rows were deleted'));
    }

    /**
     * 后台确认收款 / 结算：把订单置为“已确认”，并执行结算（商品入库 + 卖家收益 + 团队分润）
     * 支持单条与批量。幂等：已确认订单跳过。
     */
    public function confirm($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        if (!$ids) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', $ids);
        $done = 0;
        Db::startTrans();
        try {
            foreach ($idArr as $id) {
                $order = Db::name('order')->where('id', (int) $id)->lock(true)->find();
                if (!$order) {
                    continue;
                }
                if ((int) $order['pay_status'] === 2) {
                    continue; // 已确认，跳过（幂等）
                }
                if ((int) $order['pay_status'] === 3) {
                    continue; // 已取消，跳过
                }
                OrderService::settle($order);
                Db::name('order')->where('id', $order['id'])->update([
                    'pay_status'   => 2,
                    'confirm_time' => time(),
                    'updatetime'   => time(),
                ]);
                $done++;
            }
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('结算失败：' . $e->getMessage());
        }
        $this->success('已确认收款并结算 ' . $done . ' 笔');
    }

    /**
     * 后台结算：把抢中(待付款)的订单标记为「已结算待付款」，
     * 之后买家才能在前端上传付款凭证、查看对方收款方式（对照示例站流程）。
     * 支持单条与批量。幂等：非待付款订单跳过。
     */
    public function settle($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        if (!$ids) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', $ids);
        $done = Db::name('order')
            ->whereIn('id', $idArr)
            ->where('pay_status', 0)
            ->where('settle_status', 0)
            ->update(['settle_status' => 1, 'updatetime' => time()]);

        // 整轮结算：对照示例站「结算(order/balance)」—— 结算即按差价净额自动生成
        // 「会员→会员」付款单(fa_pay_order)，无需在付款订单页手动点「生成」，也不产生对公账单。
        $subIds = Db::name('order')->whereIn('id', $idArr)->where('subarea_id', '>', 0)->distinct(true)->column('subarea_id');
        $genTotal = 0;
        $genSum = 0;
        foreach ($subIds as $sid) {
            try {
                list($cnt, , , $sum) = \app\common\library\SettlementService::generate((int) $sid);
                $genTotal += (int) $cnt;
                $genSum = round($genSum + (float) $sum, 2);
            } catch (Exception $e) {
                // 单场次生成失败不阻断其它场次
            }
        }
        $this->success('已结算 ' . $done . ' 笔；自动生成会员差价付款单 ' . $genTotal . ' 条，合计 ' . $genSum . ' 元，买家可在前端上传差额付款凭证');
    }

    /**
     * 拆分（甲方口径：一键固定拆两单，平均分配）：
     *   例：张三一单 1000 元 → 点击「拆分」→ 拆成两单，各 500 元（相加=原单金额）。
     *   处理（POST，无需弹窗，前端点「拆分」直接确认执行）：
     *     1) 金额平均分成两份（奇数分不尽时首单进位，保证两份之和=原单金额）。
     *     2) 复制本商品：为每一份新建一条「委卖中(status=2)」仓库挂牌（归属原持有人=卖方），
     *        并复制其在「商品列表(subarea_goods)」的挂牌（价格改为拆分价），使前端/商品列表出现两件。
     *     3) 删除原来的抢购订单，并把原仓库持仓下架(status=0)。
     *     4) 生成两条新的「卖方抢购订单(type=2, 卖方=持有人, 买方=空)」——即两条委卖单，
     *        委卖状态展示在「委卖订单」；前端委卖订单不再显示原来的单子。
     */
    public function split($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = (int) ($ids ?: $this->request->post('ids'));
        $order = Db::name('order')->where('id', $ids)->find();
        if (!$order) {
            $this->error('订单未找到(ID:' . $ids . ')');
        }
        // 持有人=当前商品归属会员：买家(已购入持有)优先，否则卖家(委卖挂牌)
        $holder = (int) $order['buyer_id'] > 0 ? (int) $order['buyer_id'] : (int) $order['seller_id'];
        if ($holder <= 0) {
            $this->error('该订单无持有会员，无法拆分');
        }
        $amount = round((float) $order['amount'], 2);
        if ($amount <= 0) {
            $this->error('该订单金额为 0，无法拆分');
        }
        // 平均分成两份：首单进位吸收奇数分，保证两份之和严格等于原单金额
        $half2 = round($amount / 2, 2);
        $half1 = round($amount - $half2, 2);
        $parts = [$half1, $half2];

        $goodsId    = (int) $order['goods_id'];
        $subareaId  = (int) $order['subarea_id'];
        $srcWhId    = (int) $order['warehouse_id'];
        $now        = time();

        Db::startTrans();
        try {
            // 定位原仓库持仓（用于下架 + 复制其挂牌属性）
            $srcWh = null;
            if ($srcWhId > 0) {
                $srcWh = Db::name('warehouse')->where('id', $srcWhId)->find();
            }
            if (!$srcWh) {
                $srcWh = Db::name('warehouse')->where('order_id', $ids)->order('id desc')->find();
            }
            // 原持有人在「商品列表」中的挂牌（用于复制商品，价格改为拆分价）
            $srcSg = Db::name('subarea_goods')
                ->where('goods_id', $goodsId)->where('subarea_id', $subareaId)
                ->where('user_id', $holder)->order('id desc')->find();

            foreach ($parts as $price) {
                $price = round((float) $price, 2);
                // 1) 新建委卖中仓库持仓（归属持有人）
                $newWhId = Db::name('warehouse')->insertGetId([
                    'user_id'      => $holder,
                    'goods_id'     => $goodsId,
                    'subarea_id'   => $subareaId,
                    'order_id'     => 0,
                    'buy_price'    => $price,
                    'sell_price'   => $price,
                    'status'       => 2, // 委卖中
                    'selling_time' => $now,
                    'createtime'   => $now,
                    'updatetime'   => $now,
                ]);
                // 2) 生成一条卖方抢购订单（委卖单：卖方=持有人，买方=空）
                $newOrderId = Db::name('order')->insertGetId([
                    'order_no'      => date('YmdHis') . str_pad((string) mt_rand(0, 99999), 5, '0', STR_PAD_LEFT),
                    'type'          => 2,
                    'buyer_id'      => 0,
                    'seller_id'     => $holder,
                    'goods_id'      => $goodsId,
                    'subarea_id'    => $subareaId,
                    'warehouse_id'  => $newWhId,
                    'amount'        => $price,
                    'pay_type'      => 0,
                    'pay_status'    => 0,
                    'settle_status' => 0,
                    'remark'        => '拆分委卖(原单#' . $ids . ')',
                    'createtime'    => $now,
                    'updatetime'    => $now,
                ]);
                Db::name('warehouse')->where('id', $newWhId)->update(['order_id' => $newOrderId]);
                // 3) 复制商品（商品列表挂牌），价格改为拆分价；无原挂牌时新建一条
                if ($srcSg) {
                    $sgNew = $srcSg;
                    unset($sgNew['id']);
                    $sgNew['price']      = $price;
                    $sgNew['stock']      = 1;
                    $sgNew['status']     = 1;
                    $sgNew['createtime'] = $now;
                    $sgNew['updatetime'] = $now;
                    Db::name('subarea_goods')->insert($sgNew);
                }
            }

            // 4) 原仓库持仓下架 + 删除原抢购订单
            if ($srcWh) {
                Db::name('warehouse')->where('id', $srcWh['id'])->update(['status' => 0, 'updatetime' => $now]);
            }
            Db::name('order')->where('id', $ids)->delete();

            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('拆分失败：' . $e->getMessage());
        }
        $this->success('拆分成功：原单 ' . $amount . ' 元 → 两单（' . $half1 . ' 元 + ' . $half2 . ' 元），已生成两条委卖订单');
    }

    /**
     * 下架：将订单对应仓库商品下架（状态置为 0）
     */
    public function offline($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        $order = $this->model->get($ids);
        if (!$order) {
            $this->error(__('No Results were found'));
        }
        $whId = (int) $order['warehouse_id'];
        if ($whId > 0) {
            \think\Db::name('warehouse')->where('id', $whId)->update([
                'status'     => 0,
                'updatetime' => time(),
            ]);
        }
        $this->success('已下架');
    }

    /**
     * 批量上架（挂售）：把所选订单关联的「持有(1)/待上架(5)」仓库商品上架到本场寄售池(status=2)。
     * 对照甲方挂售流程：会员提交上架费凭证后，后台在「抢购订单」批量上架 → 商品进入抢购板，
     * 同时「商品管理(商品列表)」价格更新为溢价后的价格。
     */
    public function online($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        if (!$ids) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', $ids);
        $increaseFee = (float) Db::name('config')->where('name', 'increaseFee')->value('value');
        $listingFee  = (float) Db::name('config')->where('name', 'listingFee')->value('value');
        $orders = Db::name('order')->whereIn('id', $idArr)->where('warehouse_id', '>', 0)->select();
        $done = 0;
        $blocked = 0;
        Db::startTrans();
        try {
            foreach ($orders as $o) {
                // 上架费审核门槛（对照甲方上架费流程）：配置了手续费(listingFee>0)时，
                //   必须先有「已确认(pay_status=2)」的上架费付款单，后台才能批量上架该商品。
                if ($listingFee > 0) {
                    $fee = Db::name('pay_order')->where('order_id', $o['id'])->where('kind', 2)
                        ->order('id desc')->find();
                    if (!$fee || (int) $fee['pay_status'] !== 2) {
                        $blocked++;
                        continue;
                    }
                }
                // 取「本单买家结算后持有的仓库行」(settle 时新建：user_id=买家, order_id=本单)，
                //   它就是要上架的商品——卖方将变为上一轮买家。接受 持有(1)/委卖中(2,重复上架)/待上架(5)，
                //   只跳过 已售出(3)/抢购锁定(4)。用 user_id=买家 精确定位，避免误取同单已卖出的原始挂牌(status=3)。
                $wh = null;
                if ((int) $o['buyer_id'] > 0) {
                    $wh = Db::name('warehouse')
                        ->where('order_id', $o['id'])
                        ->where('user_id', (int) $o['buyer_id'])
                        ->whereIn('status', [1, 2, 5])
                        ->order('id desc')->find();
                }
                // 兜底：加仓/占位单(买方为空)等场景，回退到关联仓库行
                if (!$wh) {
                    $wh = Db::name('warehouse')->where('order_id', $o['id'])->whereIn('status', [1, 2, 5])->order('id desc')->find();
                }
                if (!$wh) {
                    $wh = Db::name('warehouse')->where('id', $o['warehouse_id'])->whereIn('status', [1, 2, 5])->find();
                }
                if (!$wh) {
                    continue;
                }
                $sellPrice = (float) $wh['sell_price'] > 0
                    ? (float) $wh['sell_price']
                    : round((float) $wh['buy_price'] * (1 + $increaseFee / 100), 2);
                $now = time();
                Db::name('warehouse')->where('id', $wh['id'])->update([
                    'status'       => 2,
                    'sell_price'   => $sellPrice,
                    'selling_time' => $now,   // 归入本场，进入抢购板
                    'updatetime'   => $now,
                ]);
                // 商品列表价格更新为溢价后的价格：只更新「当前归属会员名下、本款最近一条」挂牌(单行)，
                //   避免同款多挂牌串号。
                $sgWhere = ['goods_id' => $wh['goods_id'], 'subarea_id' => $wh['subarea_id']];
                if ($wh['user_id']) {
                    $sgWhere['user_id'] = $wh['user_id'];
                }
                $sg = Db::name('subarea_goods')->where($sgWhere)->order('id desc')->find();
                if ($sg) {
                    Db::name('subarea_goods')->where('id', $sg['id'])
                        ->update(['price' => $sellPrice, 'updatetime' => $now]);
                }
                // 每上架 1 件 → 生成 1 条新的「抢购订单(委卖单)」：卖方=当前持有人(上架前的买方)、
                //   买方=空，等待本场其他会员抢购。抢中时 buyWarehouse 会复用该占位单流转，避免重复。
                //   (对照甲方反馈：批量上架 N 单后，抢购订单应新增 N 条只有卖方的单，前端抢购出现这些商品)
                $placeholder = Db::name('order')
                    ->where('warehouse_id', $wh['id'])
                    ->where('seller_id', (int) $wh['user_id'])
                    ->where('buyer_id', 0)
                    ->order('id desc')->find();
                if ($placeholder) {
                    // 已有占位单(如加仓单本身) → 同步挂售价、重置为待抢状态
                    Db::name('order')->where('id', $placeholder['id'])->update([
                        'amount'        => $sellPrice,
                        'pay_status'    => 0,
                        'settle_status' => 0,
                        'updatetime'    => $now,
                    ]);
                } else {
                    Db::name('order')->insert([
                        'order_no'      => date('YmdHis') . str_pad((string) mt_rand(0, 99999), 5, '0', STR_PAD_LEFT),
                        'type'          => 2,
                        'buyer_id'      => 0,
                        'seller_id'     => (int) $wh['user_id'],
                        'goods_id'      => (int) $wh['goods_id'],
                        'subarea_id'    => (int) $wh['subarea_id'],
                        'warehouse_id'  => (int) $wh['id'],
                        'amount'        => $sellPrice,
                        'pay_type'      => 0,
                        'pay_status'    => 0,
                        'settle_status' => 0,
                        'remark'        => '批量上架挂售',
                        'createtime'    => $now,
                        'updatetime'    => $now,
                    ]);
                }
                $done++;
            }
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('上架失败：' . $e->getMessage());
        }
        $msg = '已上架 ' . $done . ' 件商品到本场抢购';
        if ($blocked) {
            $msg .= '；' . $blocked . ' 单上架费未审核通过，暂不能上架（请先在「付款订单」审核上架费）';
        }
        $this->success($msg);
    }

    /**
     * 指派：把订单指派给其他会员（对照示例站 order/hair）。
     *   GET  弹窗：选择会员
     *   POST 将订单买方(buyer_id) 改为所选会员，并同步转移关联仓库持仓归属(warehouse.user_id)。
     */
    public function hair($ids = null)
    {
        $ids = (int) ($ids ?: $this->request->param('ids'));
        $order = Db::name('order')->where('id', $ids)->find();
        if (!$order) {
            $this->error('订单未找到(ID:' . $ids . ')');
        }
        if ($this->request->isPost()) {
            $row = $this->request->post('row/a', []);
            $uid = (int) ($row['user_id'] ?? $this->request->post('user_id'));
            if ($uid <= 0) {
                $this->error('请选择要指派的会员');
            }
            $user = Db::name('user')->where('id', $uid)->find();
            if (!$user) {
                $this->error('所选会员不存在');
            }
            Db::startTrans();
            try {
                Db::name('order')->where('id', $ids)->update([
                    'buyer_id'   => $uid,
                    'updatetime' => time(),
                ]);
                // 同步转移关联仓库持仓归属
                if ((int) $order['warehouse_id'] > 0) {
                    Db::name('warehouse')->where('id', $order['warehouse_id'])->update([
                        'user_id'    => $uid,
                        'updatetime' => time(),
                    ]);
                }
                Db::commit();
            } catch (Exception $e) {
                Db::rollback();
                $this->error('指派失败：' . $e->getMessage());
            }
            $this->success('已指派给会员：' . ($user['nickname'] ?: ('会员' . $uid)));
        }
        $this->view->assign('row', $order);
        return $this->view->fetch();
    }

    /**
     * 取消订单（对照甲方：取消买方本单，商品回到抢购池，前台可重新抢购）
     *   - 会员寄售单(type=2)：关联仓库退回「委卖中(2)」并刷新挂售时间(归入本场)，
     *     订单还原为「占位委卖单」(买方清空、状态重置)，同时把本单未完成的付款单置为已取消。
     *   - 平台抢购单(type=1)：恢复对应商品库存(subarea_goods.stock+1、上架)，删除本订单，
     *     买家可重新抢购。
     *   已确认收款(pay_status=2)的订单不允许取消(需先撤销结算)，避免破坏已入库/已分润数据。
     */
    public function cancel($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        if (!$ids) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', $ids);
        $done = 0;
        $skipped = 0;
        Db::startTrans();
        try {
            foreach ($idArr as $id) {
                $order = Db::name('order')->where('id', (int) $id)->lock(true)->find();
                if (!$order) {
                    continue;
                }
                if ((int) $order['pay_status'] === 2) {
                    $skipped++; // 已确认收款不可取消
                    continue;
                }
                $now = time();
                // 本单未完成的付款单(差价/全额/上架费) → 置为已取消
                Db::name('pay_order')->where('order_id', $order['id'])
                    ->whereIn('pay_status', [0, 1])->update(['pay_status' => 3, 'updatetime' => $now]);

                if ((int) $order['type'] === 2) {
                    // 会员寄售：仓库退回委卖中(2)，订单还原为占位委卖单(买方清空)
                    $wid = (int) $order['warehouse_id'];
                    if ($wid > 0) {
                        Db::name('warehouse')->where('id', $wid)->whereIn('status', [2, 4])->update([
                            'status'       => 2,
                            'selling_time' => $now, // 归入本场，前台重新出现在抢购池
                            'updatetime'   => $now,
                        ]);
                    }
                    Db::name('order')->where('id', $order['id'])->update([
                        'buyer_id'      => 0,
                        'pay_status'    => 0,
                        'settle_status' => 0,
                        'pay_time'      => 0,
                        'confirm_time'  => 0,
                        'remark'        => '后台取消买方，重新委卖',
                        'updatetime'    => $now,
                    ]);
                } else {
                    // 平台抢购：恢复商品库存，删除本订单，前台可重新抢购
                    $sg = Db::name('subarea_goods')
                        ->where('goods_id', (int) $order['goods_id'])
                        ->where('subarea_id', (int) $order['subarea_id'])
                        ->order('id desc')->find();
                    if ($sg) {
                        Db::name('subarea_goods')->where('id', $sg['id'])->update([
                            'stock'      => (int) $sg['stock'] + 1,
                            'status'     => 1,
                            'updatetime' => $now,
                        ]);
                    }
                    Db::name('order')->where('id', $order['id'])->delete();
                }
                $done++;
            }
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('取消失败：' . $e->getMessage());
        }
        $msg = '已取消 ' . $done . ' 单，商品已回到抢购池，前台可重新抢购';
        if ($skipped) {
            $msg .= '；' . $skipped . ' 单已确认收款不可取消';
        }
        $this->success($msg);
    }

    /**
     * 一键清空交易数据（对照甲方反馈：后台清空后前端/首页统计也应归零）
     *   清空：抢购板(subarea_goods) / 仓库(warehouse) / 抢购订单(order) / 付款订单(pay_order)
     *        / 资金流水(user_money_log) / 团队收益流水(profit_log)，并把会员余额、积分、冻结金额重置为 0。
     *   不动：会员账号、商品库(goods)、场次(subarea)、签约、配置。
     */
    public function clearData()
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        Db::startTrans();
        try {
            $clear = function ($table) {
                if (Db::query("SHOW TABLES LIKE '" . config('database.prefix') . $table . "'")) {
                    Db::name($table)->where('1=1')->delete();
                }
            };
            $clear('subarea_goods');
            $clear('warehouse');
            $clear('order');
            $clear('pay_order');
            $clear('user_money_log');
            $clear('profit_log');
            // 重置会员资金字段（余额/积分/冻结），让前端「我的/资金流水/团队收益」同步归零。
            // 仅更新实际存在的列，避免不同库结构差异导致报错。
            $userCols = array_map(function ($c) {
                return $c['Field'];
            }, Db::query("SHOW COLUMNS FROM " . config('database.prefix') . "user"));
            $reset = ['updatetime' => time()];
            foreach (['money', 'score', 'freeze', 'frozen', 'frozen_money'] as $col) {
                if (in_array($col, $userCols)) {
                    $reset[$col] = 0;
                }
            }
            Db::name('user')->where('1=1')->update($reset);
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('清空失败：' . $e->getMessage());
        }
        $this->success('已清空全部交易数据（订单/仓库/抢购板/付款单/资金流水），会员余额已重置');
    }

    /**
     * 开启转售（对照甲方「上架费流程」）：
     *   后台对所选订单开启转售 → 商品置「待上架(status=5)」并按溢价重算挂售价，
     *   同时生成一条「上架费」付款单(fa_pay_order, kind=2)：付款人=当前持有会员，收款人=平台(0)。
     *   会员在 H5「委卖订单」看到该上架费、展示平台收款码、上传凭证 → 后台「付款订单」审核 →
     *   审核通过后后台才能对该商品「批量上架」进入抢购板。
     *   （手续费 listingFee=0 时不产生上架费，开启转售即可直接批量上架。）
     */
    public function resale($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        if (!$ids) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', $ids);
        $increaseFee = (float) Db::name('config')->where('name', 'increaseFee')->value('value');
        $listingFee  = (float) Db::name('config')->where('name', 'listingFee')->value('value');
        $bizMode = (int) Db::name('config')->where('name', 'biz_mode')->value('value');
        $orders = Db::name('order')->whereIn('id', $idArr)->where('warehouse_id', '>', 0)->select();
        $done = 0;
        $skipped = 0;
        $feeCnt = 0;
        Db::startTrans();
        try {
            // 简化转售模式：开启转售 = 给买家持有的仓库行打开「转售」开关(resell=1)，
            //   保持持有(status=1)，不生成上架费；买家在 H5 买方仓库点「转售」后进入委卖中。
            if ($bizMode === 1) {
                foreach ($orders as $o) {
                    $wh = null;
                    if ((int) $o['buyer_id'] > 0) {
                        $wh = Db::name('warehouse')->where('order_id', $o['id'])
                            ->where('user_id', (int) $o['buyer_id'])->where('status', 1)->order('id desc')->find();
                    }
                    if (!$wh) {
                        $wh = Db::name('warehouse')->where('order_id', $o['id'])->where('status', 1)->order('id desc')->find();
                    }
                    if (!$wh) {
                        $skipped++;
                        continue;
                    }
                    Db::name('warehouse')->where('id', $wh['id'])->update([
                        'resell'      => 1,
                        'resell_time' => time(),
                        'updatetime'  => time(),
                    ]);
                    $done++;
                }
                Db::commit();
                $msg = '已开启转售 ' . $done . ' 件商品（会员可在买方仓库点「转售」进入委卖中）';
                if ($skipped) {
                    $msg .= '；' . $skipped . ' 单不在持有状态，已跳过';
                }
                $this->success($msg);
            }
            foreach ($orders as $o) {
                // 取「本单买家结算后持有的仓库行」(settle 新建, user_id=买家, order_id=本单)。
                // 只对「持有(1)/待上架(5)」的行转售；已售出(3)/委卖中(2)/锁定(4) 跳过。
                $wh = null;
                if ((int) $o['buyer_id'] > 0) {
                    $wh = Db::name('warehouse')->where('order_id', $o['id'])
                        ->where('user_id', (int) $o['buyer_id'])->whereIn('status', [1, 5])->order('id desc')->find();
                }
                if (!$wh) {
                    $wh = Db::name('warehouse')->where('order_id', $o['id'])->whereIn('status', [1, 5])->order('id desc')->find();
                }
                if (!$wh) {
                    $wh = Db::name('warehouse')->where('id', $o['warehouse_id'])->whereIn('status', [1, 5])->find();
                }
                if (!$wh) {
                    $skipped++;
                    continue;
                }
                $sellPrice = round((float) $wh['buy_price'] * (1 + $increaseFee / 100), 2);
                $now = time();
                // 待上架(5)：等待会员付上架费并经后台审核后，再由「批量上架」进入抢购板
                Db::name('warehouse')->where('id', $wh['id'])->update([
                    'status'       => 5,
                    'sell_price'   => $sellPrice,
                    'selling_time' => $now,
                    'updatetime'   => $now,
                ]);
                // 生成上架费付款单（会员→平台），幂等：本单已有未取消的上架费单则不重复生成
                if ($listingFee > 0 && (int) $wh['user_id'] > 0) {
                    $feeAmount = round($sellPrice * $listingFee / 100, 2);
                    if ($feeAmount > 0) {
                        $exist = Db::name('pay_order')->where('order_id', $o['id'])->where('kind', 2)
                            ->whereIn('pay_status', [0, 1, 2])->find();
                        if (!$exist) {
                            Db::name('pay_order')->insert([
                                'subarea_id'      => (int) $wh['subarea_id'],
                                'order_id'        => (int) $o['id'],
                                'user_id'         => (int) $wh['user_id'], // 付款人=持有会员
                                'collect_user_id' => 0,                    // 收款人=平台
                                'price'           => $feeAmount,
                                'kind'            => 2,                    // 上架费
                                'is_listing'      => 0,
                                'pay_type'        => 0,
                                'pay_status'      => 0,                    // 待支付
                                'remark'          => '上架费',
                                'createtime'      => $now,
                                'updatetime'      => $now,
                            ]);
                            $feeCnt++;
                        }
                    }
                }
                $done++;
            }
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('开启转售失败：' . $e->getMessage());
        }
        $msg = '已开启转售 ' . $done . ' 件商品';
        if ($feeCnt) {
            $msg .= '，生成上架费付款单 ' . $feeCnt . ' 条（待会员上传凭证、后台审核后可批量上架）';
        } elseif ($listingFee <= 0) {
            $msg .= '（未配置上架费，可直接批量上架）';
        }
        if ($skipped) {
            $msg .= '；' . $skipped . ' 单已售出/已在售，无需转售';
        }
        $this->success($msg);
    }
}

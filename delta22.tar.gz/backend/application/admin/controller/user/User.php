<?php

namespace app\admin\controller\user;

use app\common\controller\Backend;
use app\common\library\Auth;

/**
 * 会员管理
 *
 * @icon fa fa-user
 */
class User extends Backend
{

    protected $relationSearch = true;
    protected $searchFields = 'id,username,nickname,mobile';
    // 指派会员下拉(selectpage)返回的字段：需带上 mobile，供「手机号模糊搜索 + 显示」
    protected $selectpageFields = 'id,username,nickname,mobile';

    /**
     * @var \app\admin\model\User
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\User;
    }

    /**
     * 查看
     */
    public function index()
    {
        //设置过滤方法
        $this->request->filter(['strip_tags', 'trim']);
        if ($this->request->isAjax()) {
            //如果发送的来源是Selectpage，则转发到Selectpage
            if ($this->request->request('keyField')) {
                return $this->selectpage();
            }
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $list = $this->model
                ->where($where)
                ->order($sort, $order)
                ->paginate($limit);
            foreach ($list as $k => $v) {
                $v->avatar = $v->avatar ? cdnurl($v->avatar, true) : letter_avatar($v->nickname);
                $v->hidden(['password', 'salt']);
                // 等级名称（经销商/经理/老板）与团队分组人数
                $level = isset($v->level) ? (int) $v->level : 1;
                $v->level_name = \app\common\library\TeamService::levelName($level);
                $stat = \app\common\library\TeamService::groupStat($v->id);
                $v->team_total = $stat['total'];
                $v->distributor_count = $stat['distributor'];
                $v->manager_total = $stat['manager'];
                $v->boss_count = $stat['boss'];
                // 上级会员（昵称/手机号）
                $parent = $v->pid ? \think\Db::name('user')->where('id', $v->pid)->field('nickname,mobile')->find() : null;
                $v->parent_name = $parent ? ($parent['nickname'] ?: $parent['mobile']) : '—';
                // 签约名称（已签约姓名）
                $v->signing_name = \think\Db::name('signing')->where('user_id', $v->id)->order('id desc')->value('name') ?: '';
                // 抢购次数：只统计「当天」抢购单数（按下单时间当天；次日自动从0开始，不累加）
                $v->buy_count = \think\Db::name('order')
                    ->where('buyer_id', $v->id)
                    ->where('type', 'in', [1, 2])
                    ->where('createtime', '>=', strtotime('today'))
                    ->count();
                $v->position = $v->is_team == 1 ? '团队长' : '普通用户';
            }
            $rows = $list->items();
            addtion($rows, [['field' => 'group_id', 'display' => 'group_name', 'model' => \app\admin\model\UserGroup::class]]);
            $result = array("total" => $list->total(), "rows" => $rows);

            return json($result);
        }
        $this->assignconfig('multi_delete_user', config('fastadmin.multi_delete_user'));
        return $this->view->fetch();
    }

    /**
     * 添加会员（单个）：正确生成盐值并加密密码，保证会员能在前台正常登录。
     *   用户名/手机号至少填一个；密码留空默认 123456；自动补全 nickname/邀请码/加入时间等基础字段。
     */
    public function add()
    {
        if ($this->request->isPost()) {
            $this->token();
            $params = $this->request->post('row/a', [], 'trim');
            if (!$params) {
                $this->error(__('Parameter %s can not be empty', 'row'));
            }
            $mobile   = trim((string) ($params['mobile'] ?? ''));
            $username = trim((string) ($params['username'] ?? ''));
            if ($username === '' && $mobile === '') {
                $this->error('用户名和手机号至少填写一个');
            }
            if ($username === '') {
                $username = $mobile;
            }
            if (\think\Db::name('user')->where('username', $username)->find()) {
                $this->error('用户名已存在：' . $username);
            }
            if ($mobile !== '' && \think\Db::name('user')->where('mobile', $mobile)->find()) {
                $this->error('手机号已存在：' . $mobile);
            }
            $password = ($params['password'] ?? '') !== '' ? (string) $params['password'] : '123456';
            try {
                $uid = $this->createMember([
                    'username' => $username,
                    'nickname' => (string) ($params['nickname'] ?? ''),
                    'mobile'   => $mobile,
                    'password' => $password,
                    'money'    => (float) ($params['money'] ?? 0),
                    'score'    => (int) ($params['score'] ?? 0),
                    'group_id' => (int) ($params['group_id'] ?? 0),
                    'status'   => ($params['status'] ?? 'normal') ?: 'normal',
                ]);
            } catch (\Exception $e) {
                $this->error('添加失败：' . $e->getMessage());
            }
            $this->success('添加成功！会员ID ' . $uid . '，登录密码：' . $password);
        }
        $this->view->assign('groupList', build_select('row[group_id]', \app\admin\model\UserGroup::column('id,name'), config('fastadmin.user_default_group') ?: 0, ['class' => 'form-control selectpicker']));
        return $this->view->fetch();
    }

    /**
     * 创建一个会员（供单个添加 / 批量导入共用），返回新会员ID。
     */
    protected function createMember(array $d)
    {
        $now  = time();
        $ip   = $this->request->ip();
        $salt = \fast\Random::alnum();
        $password = ($d['password'] ?? '') !== '' ? (string) $d['password'] : '123456';
        $username = (string) $d['username'];
        $data = [
            'username'    => $username,
            'nickname'    => ($d['nickname'] ?? '') !== '' ? (string) $d['nickname'] : $username,
            'mobile'      => (string) ($d['mobile'] ?? ''),
            'email'       => '',
            'avatar'      => '',
            'password'    => \app\common\library\Auth::instance()->getEncryptPassword($password, $salt),
            'salt'        => $salt,
            'money'       => (float) ($d['money'] ?? 0),   // 优惠券余额
            'profit'      => (float) ($d['profit'] ?? 0),  // 我的利润余额
            'score'       => (int) ($d['score'] ?? 0),
            'level'       => 1,
            'pid'         => 0,
            'is_team'     => 0,
            'invite_code' => strtoupper(\fast\Random::alnum(6)),
            'group_id'    => (int) ($d['group_id'] ?? 0) ?: (int) (config('fastadmin.user_default_group') ?: 1),
            'status'      => ($d['status'] ?? 'normal') ?: 'normal',
            'jointime'    => $now,
            'joinip'      => $ip,
            'logintime'   => $now,
            'loginip'     => $ip,
            'prevtime'    => $now,
            'createtime'  => $now,
            'updatetime'  => $now,
        ];
        return \think\Db::name('user')->insertGetId($data);
    }

    /**
     * 批量导入会员（csv/xls/xlsx）。
     *   导入字段：手机号 / 用户名 / 昵称 / 密码 / 优惠券余额(money) / 我的利润余额(profit)。
     *   表头支持中英文别名（如 手机号/mobile、优惠券余额/money、我的利润余额/profit）。
     *   用户名留空则用手机号；密码留空默认 123456；已存在的用户名/手机号自动跳过。
     */
    public function import()
    {
        $file = $this->request->request('file');
        if (!$file) {
            $this->error('请先上传要导入的文件');
        }
        $filePath = ROOT_PATH . 'public' . DS . $file;
        if (!is_file($filePath)) {
            $this->error('上传的文件不存在');
        }
        $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));
        if (!in_array($ext, ['csv', 'xls', 'xlsx'])) {
            $this->error('仅支持 csv / xls / xlsx 格式');
        }

        // 读取为二维数组 $rows（含表头行）
        $rows = [];
        try {
            if ($ext === 'csv') {
                $content = file_get_contents($filePath);
                $encoding = mb_detect_encoding($content, ['utf-8', 'gbk', 'gb2312', 'big5', 'latin1'], true);
                if ($encoding && strtolower($encoding) !== 'utf-8') {
                    $content = mb_convert_encoding($content, 'utf-8', $encoding);
                }
                $content = preg_replace("/^\xEF\xBB\xBF/", '', $content); // 去 BOM
                foreach (preg_split("/\r\n|\n|\r/", $content) as $line) {
                    if (trim($line) === '') {
                        continue;
                    }
                    $rows[] = str_getcsv($line);
                }
            } else {
                $reader = \PhpOffice\PhpSpreadsheet\IOFactory::createReaderForFile($filePath);
                $reader->setReadDataOnly(true);
                $spreadsheet = $reader->load($filePath);
                $rows = $spreadsheet->getSheet(0)->toArray(null, true, false, false);
            }
        } catch (\Exception $e) {
            $this->error('文件解析失败：' . $e->getMessage());
        }
        if (count($rows) < 2) {
            $this->error('文件没有数据行（第一行为表头，从第二行开始为会员数据）');
        }

        // 表头映射
        $aliases = [
            'mobile'   => ['手机号', '手机', '电话', 'mobile', 'phone'],
            'username' => ['用户名', '账号', 'username'],
            'nickname' => ['昵称', '姓名', '名称', 'nickname', 'name'],
            'password' => ['密码', 'password'],
            'money'    => ['优惠券余额', '优惠券', '余额', 'money'],
            'profit'   => ['我的利润余额', '利润余额', '利润', 'profit'],
            'score'    => ['积分', 'score'],
        ];
        $map = [];
        foreach ($rows[0] as $i => $h) {
            $h = trim((string) $h);
            foreach ($aliases as $field => $names) {
                if (in_array($h, $names, true)) {
                    $map[$i] = $field;
                    break;
                }
            }
        }
        if (!$map) {
            $this->error('未识别到有效表头，请使用「导入模板」（需包含：手机号/昵称/用户名/密码 等列）');
        }

        $ok = 0;
        $skip = 0;
        $errors = [];
        \think\Db::startTrans();
        try {
            for ($r = 1; $r < count($rows); $r++) {
                $line = $rows[$r];
                $rec = [];
                foreach ($map as $i => $field) {
                    $rec[$field] = isset($line[$i]) ? trim((string) $line[$i]) : '';
                }
                $mobile   = $rec['mobile'] ?? '';
                $username = $rec['username'] ?? '';
                if ($username === '' && $mobile === '') {
                    $skip++;
                    continue; // 空行
                }
                if ($username === '') {
                    $username = $mobile;
                }
                if (\think\Db::name('user')->where('username', $username)->find()) {
                    $skip++;
                    $errors[] = '第' . ($r + 1) . '行用户名已存在:' . $username;
                    continue;
                }
                if ($mobile !== '' && \think\Db::name('user')->where('mobile', $mobile)->find()) {
                    $skip++;
                    $errors[] = '第' . ($r + 1) . '行手机号已存在:' . $mobile;
                    continue;
                }
                $this->createMember([
                    'username' => $username,
                    'nickname' => $rec['nickname'] ?? '',
                    'mobile'   => $mobile,
                    'password' => $rec['password'] ?? '',
                    'money'    => (float) ($rec['money'] ?? 0),   // 优惠券余额
                    'profit'   => (float) ($rec['profit'] ?? 0),  // 我的利润余额
                    'score'    => (int) ($rec['score'] ?? 0),
                ]);
                $ok++;
            }
            \think\Db::commit();
        } catch (\Exception $e) {
            \think\Db::rollback();
            $this->error('导入失败：' . $e->getMessage());
        }
        $msg = '导入完成：成功 ' . $ok . ' 条，跳过 ' . $skip . ' 条（未填密码的默认 123456）';
        if ($errors) {
            $msg .= '。' . implode('；', array_slice($errors, 0, 5)) . (count($errors) > 5 ? ' 等' : '');
        }
        $this->success($msg);
    }

    /**
     * 下载批量导入模板（CSV，带 BOM，Excel 可直接打开，含中文表头与一行示例）
     */
    public function importTpl()
    {
        $filename = 'member_import_template.csv';
        header('Content-Type: text/csv; charset=utf-8');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        header('Cache-Control: no-cache');
        $bom = "\xEF\xBB\xBF"; // Excel 识别 UTF-8
        // 导入字段（顺序对照甲方要求）：手机号 / 用户名 / 昵称 / 密码 / 优惠券余额 / 我的利润余额
        $lines = [
            '手机号,用户名,昵称,密码,优惠券余额,我的利润余额',
            '13800000001,,张三,123456,0,0',
            '13800000002,lisi,李四,,0,0',
        ];
        echo $bom . implode("\r\n", $lines);
        exit;
    }

    /**
     * 编辑
     */
    public function edit($ids = null)
    {
        if ($this->request->isPost()) {
            $this->token();
        }
        $row = $this->model->get($ids);
        $this->modelValidate = true;
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $this->view->assign('groupList', build_select('row[group_id]', \app\admin\model\UserGroup::column('id,name'), $row['group_id'], ['class' => 'form-control selectpicker']));

        // 会员明细四标签（对照示例站会员编辑：余额 / 订单 / 优惠券 / 粉丝），只读流水
        if (!$this->request->isPost()) {
            $uid = (int) $row['id'];
            $fmt = function ($t) {
                return $t ? date('Y-m-d H:i', (int) $t) : '—';
            };
            // 余额流水
            $money = [];
            foreach (\think\Db::name('user_money_log')->where('user_id', $uid)->order('id desc')->limit(50)->select() as $r) {
                $money[] = [
                    'money'  => $r['money'],
                    'before' => $r['before'],
                    'after'  => $r['after'],
                    'memo'   => $r['memo'],
                    'time'   => $fmt($r['createtime']),
                ];
            }
            // 订单
            $orders = [];
            $orows = \think\Db::name('order')->alias('o')
                ->join('goods g', 'o.goods_id = g.id', 'LEFT')
                ->where('o.buyer_id', $uid)->whereOr('o.seller_id', $uid)
                ->field('o.id,o.order_no,o.type,o.buyer_id,o.seller_id,o.amount,o.pay_status,o.createtime,g.name goods_name')
                ->order('o.id desc')->limit(50)->select();
            $payStatusMap = [0 => '待付款', 1 => '待确认', 2 => '已完成'];
            foreach ($orows as $r) {
                $orders[] = [
                    'order_no'   => $r['order_no'],
                    'goods_name' => $r['goods_name'] ?: '—',
                    'amount'     => $r['amount'],
                    'role'       => ((int) $r['buyer_id'] === $uid ? '买入' : '卖出'),
                    'status'     => $payStatusMap[(int) $r['pay_status']] ?? (string) $r['pay_status'],
                    'time'       => $fmt($r['createtime']),
                ];
            }
            // 优惠券
            $coupons = [];
            $cStatus = [0 => '未使用', 1 => '已使用', 2 => '已过期'];
            foreach (\think\Db::name('user_coupon')->where('user_id', $uid)->order('id desc')->limit(50)->select() as $r) {
                $coupons[] = [
                    'amount' => $r['amount'],
                    'status' => $cStatus[(int) $r['status']] ?? (string) $r['status'],
                    'expire' => $fmt($r['expire_time']),
                    'time'   => $fmt($r['createtime']),
                ];
            }
            // 粉丝（直推下级）
            $fans = [];
            foreach (\think\Db::name('user')->where('pid', $uid)->field('id,nickname,mobile,money,createtime')->order('id desc')->limit(100)->select() as $r) {
                $fans[] = [
                    'nickname' => $r['nickname'] ?: '—',
                    'mobile'   => $r['mobile'],
                    'money'    => $r['money'],
                    'time'     => $fmt($r['createtime']),
                ];
            }
            $this->view->assign('tabMoney', $money);
            $this->view->assign('tabOrders', $orders);
            $this->view->assign('tabCoupons', $coupons);
            $this->view->assign('tabFans', $fans);
        }
        return parent::edit($ids);
    }

    /**
     * 冻结 / 解冻会员（在 normal 与 hidden 之间切换）
     */
    public function freeze($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        $row = $this->model->get($ids);
        if (!$row) {
            $this->error(__('No Results were found'));
        }
        $row->status = $row->status === 'normal' ? 'hidden' : 'normal';
        $row->save();
        $this->success($row->status === 'normal' ? '已解冻' : '已冻结');
    }

    /**
     * 删除
     */
    public function del($ids = "")
    {
        if (!$this->request->isPost()) {
            $this->error(__("Invalid parameters"));
        }
        $ids = $ids ?: $this->request->post("ids");
        $ids = array_filter(explode(',', $ids));
        if (!(config('fastadmin.multi_delete_user') ?: false)) {
            if (count($ids) > 1) {
                $this->error(__('Multi delete is not allowed'));
            }
            $row = $this->model->get($ids);
            $this->modelValidate = true;
            if (!$row) {
                $this->error(__('No Results were found'));
            }
            $result = Auth::instance()->delete($row['id']);
            $count = $result ? 1 : 0;
            if ($count) {
                $this->success();
            }
        } else {
            //允许批量删除
            $list = $this->model->where('id', 'in', $ids)->select();
            $count = 0;
            foreach ($list as $item) {
                $result = Auth::instance()->delete($item['id']);
                if ($result) {
                    $count++;
                }
            }
        }
        if ($count) {
            $this->success(__('%s rows deleted succeeded, %s rows deleted failed', $count, count($ids) - $count));
        } else {
            $this->error(__('No rows were deleted'));
        }
    }

}

<?php

namespace app\admin\controller\subarea;

use app\common\controller\Backend;
use think\Db;
use think\Exception;

/**
 * 专区商品
 *
 * @icon fa fa-circle-o
 */
class Goods extends Backend
{

    /**
     * Goods模型对象
     * @var \app\admin\model\subarea\Goods
     */
    protected $model = null;

    public function _initialize()
    {
        parent::_initialize();
        $this->model = new \app\admin\model\subarea\Goods;
        $this->view->assign("typeList", $this->model->getTypeList());
        $this->view->assign("statusList", $this->model->getStatusList());
    }

    /**
     * 列表（字段对照示例站：手机号/场次名称/商品名称/商品价格/封面图/轮播图/创建时间/操作）
     */
    public function index()
    {
        if ($this->request->isAjax()) {
            list($where, $sort, $order, $offset, $limit) = $this->buildparams();
            $list = $this->model->where($where)->order($sort, $order)->paginate($limit);
            foreach ($list as $row) {
                $g = Db::name('goods')->where('id', $row['goods_id'])->field('name,image,images')->find();
                $row->subarea_name = Db::name('subarea')->where('id', $row['subarea_id'])->value('name') ?: '';
                $row->goods_name   = $g['name'] ?? '';
                $row->cover_image  = !empty($g['image']) ? cdnurl($g['image'], true) : '';
                $imgs = !empty($g['images']) ? array_filter(explode(',', $g['images'])) : [];
                $row->carousel_image = !empty($imgs) ? cdnurl(trim(reset($imgs)), true) : '';
                // 归属会员：直接用「本行 user_id」（指派写入；抢购成交后由结算更新为最新买家），
                //   不再按 goods_id 反查成交单，避免同款多挂牌(同 goods_id)串号。
                $mobile = '';
                $ownerId = (int) ($row['user_id'] ?? 0);
                if ($ownerId > 0) {
                    $u = Db::name('user')->where('id', $ownerId)->field('nickname,mobile')->find();
                    if ($u) {
                        $mobile = ($u['mobile'] ?: '无号码') . '(' . ($u['nickname'] ?: ('会员' . $ownerId)) . ')';
                    }
                }
                $row->mobile = $mobile;
            }
            return json(["total" => $list->total(), "rows" => $list->items()]);
        }
        return $this->view->fetch();
    }

    /**
     * 删除专区商品：同时级联清理「仍在委卖中(未成交)」的仓库与占位订单，
     * 避免删除后前端抢购板仍显示孤儿记录（对照用户反馈：删了商品前端还显示）。
     * 已成交/交易中(仓库 status=3/4) 的不动，以免破坏历史成交数据。
     */
    public function del($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__('Invalid parameters'));
        }
        $ids = $ids ?: $this->request->post('ids');
        if (empty($ids)) {
            $this->error(__('Parameter %s can not be empty', 'ids'));
        }
        $idArr = is_array($ids) ? $ids : explode(',', (string) $ids);
        $rows = $this->model->where('id', 'in', $idArr)->select();
        Db::startTrans();
        try {
            foreach ($rows as $sg) {
                // 只清理「本条专区商品行」对应的委卖中(未成交)上架记录，避免误删同款其他会员/其他行的商品。
                $whIds = Db::name('warehouse')
                    ->where('sg_id', (int) $sg['id'])
                    ->where('status', 2)
                    ->column('id');
                // 兼容历史无 sg_id 的记录：按 归属会员+同款+委卖中 精确匹配(不再按 goods_id 一刀切)
                if (!$whIds && (int) ($sg['user_id'] ?? 0) > 0) {
                    $whIds = Db::name('warehouse')
                        ->where('goods_id', $sg['goods_id'])->where('subarea_id', $sg['subarea_id'])
                        ->where('user_id', (int) $sg['user_id'])->where('sg_id', 0)
                        ->where('status', 2)
                        ->column('id');
                }
                if ($whIds) {
                    Db::name('order')->whereIn('warehouse_id', $whIds)->where('buyer_id', 0)->delete();
                    Db::name('warehouse')->whereIn('id', $whIds)->delete();
                }
            }
            $count = $this->model->where('id', 'in', $idArr)->delete();
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('删除失败：' . $e->getMessage());
        }
        if ($count) {
            $this->success();
        }
        $this->error(__('No rows were deleted'));
    }

    /**
     * 会员下拉数据（手机号-昵称），用于「指派用户」选择
     */
    public function userList()
    {
        $kw = $this->request->request('q_word', $this->request->request('keyword', ''));
        $kw = is_array($kw) ? ($kw[0] ?? '') : $kw;
        $kw = trim((string) $kw);
        $query = Db::name('user')->field('id,nickname,mobile,username');
        if ($kw !== '') {
            // 支持 手机号 / 昵称 / 用户名 模糊搜索
            $query->where('mobile|nickname|username', 'like', '%' . $kw . '%');
        }
        // 不再限制 50 条：无关键词时返回全部会员；有关键词按手机号/昵称模糊匹配（上限 1000 防极端）
        $rows = $query->order('id desc')->limit(1000)->select();
        $list = [];
        foreach ($rows as $u) {
            $list[] = [
                'id'   => $u['id'],
                'name' => ($u['mobile'] ?: '无号码') . '(' . ($u['nickname'] ?: '会员' . $u['id']) . ')',
            ];
        }
        return json(['list' => $list]);
    }

    /**
     * 指派用户：把某条专区商品指派给指定会员，使其在该会员名下「委卖中」
     * 同时生成：
     *   1) 一条 warehouse 记录（status=2 委卖中，sell_price=商品价格）→ 前端卖方仓库显示「委卖中」
     *   2) 一条 order 记录（type=2，seller_id=会员，buyer_id=0）→ 后台抢购订单 / 前端「我的订单」显示「委卖中」
     * @param int $ids 专区商品ID
     * 注意：方法名不能用 assign（与 think\Controller::assign 冲突会导致控制器致命错误）
     */
    public function assignuser($ids = null)
    {
        if (!$this->request->isPost()) {
            $this->error(__('Invalid parameters'));
        }
        $ids = $ids ?: $this->request->post('ids');
        $userId = (int) $this->request->post('user_id');
        if (!$ids || !$userId) {
            $this->error('请选择商品与会员');
        }
        $sg = $this->model->where('id', (int) $ids)->find();
        if (!$sg) {
            $this->error('专区商品不存在');
        }
        $user = Db::name('user')->where('id', $userId)->find();
        if (!$user) {
            $this->error('会员不存在');
        }
        // 价格兜底：专区价为 0 时引用首页商品模型价格，避免抢购专区显示 ¥0
        $price = (float) $sg['price'];
        if ($price <= 0) {
            $price = (float) Db::name('goods')->where('id', $sg['goods_id'])->value('price');
        }
        Db::startTrans();
        try {
            $now = time();
            // 防重（重点：连点/并发多次指派不能生成多条抢购订单）：
            //   先对本条专区商品行加行锁(FOR UPDATE)串行化——第二个并发请求会阻塞，
            //   等第一个提交后再执行，届时下面按 sg_id 就能查到已生成的仓库/订单并复用，绝不重复生成。
            Db::name('subarea_goods')->where('id', (int) $sg['id'])->lock(true)->find();
            // 按「本条专区商品行(sg.id)」一一对应仓库记录：同款同人可有多条(每条专区商品=一件独立寄售)，
            //   不再按 goods_id+user 去重合并(那会把"给同一人加两单"塌缩成一单，前端只显示一件)。
            //   优先复用本行已生成的仓库(sg_id=本行)，其次兼容历史无 sg_id 的同款同人在售行(认领一条)。
            //   status=4(已被抢锁定)/3(已售出) 视为已进入交易，不复用，本次按新一轮上架处理。
            $exist = Db::name('warehouse')
                ->where('sg_id', (int) $sg['id'])
                ->whereIn('status', [1, 2, 5])
                ->order('id desc')->lock(true)->find();
            if (!$exist) {
                $exist = Db::name('warehouse')
                    ->where('goods_id', $sg['goods_id'])->where('subarea_id', $sg['subarea_id'])
                    ->where('user_id', $userId)->where('sg_id', 0)
                    ->whereIn('status', [1, 2, 5])
                    ->order('id asc')->find();
            }
            if ($exist) {
                $whId = (int) $exist['id'];
                Db::name('warehouse')->where('id', $whId)->update([
                    'user_id'      => $userId,
                    'sg_id'        => (int) $sg['id'],
                    'buy_price'    => $price,
                    'sell_price'   => $price,
                    'status'       => 2,
                    'selling_time' => $now,
                    'createtime'   => $now, // 刷新到本场，使其在前端「本场」抢购板展示
                    'updatetime'   => $now,
                ]);
                // 确保存在对应的「委卖中」占位订单（卖家可在「我的委卖订单」看到）
                $ord = Db::name('order')->where('warehouse_id', $whId)->where('seller_id', $userId)->find();
                if ($ord) {
                    $orderId = (int) $ord['id'];
                    Db::name('order')->where('id', $orderId)->update([
                        'buyer_id'   => 0,
                        'amount'     => $price,
                        'pay_status' => 2,
                        'remark'     => '后台指派委卖',
                        'createtime' => $now,
                        'updatetime' => $now,
                    ]);
                } else {
                    $orderId = Db::name('order')->insertGetId([
                        'order_no'     => 'BL' . date('YmdHis') . mt_rand(1000, 9999),
                        'type'         => 2,
                        'buyer_id'     => 0,
                        'seller_id'    => $userId,
                        'goods_id'     => $sg['goods_id'],
                        'subarea_id'   => $sg['subarea_id'],
                        'warehouse_id' => $whId,
                        'amount'       => $price,
                        'pay_type'     => 0,
                        'pay_status'   => 2,
                        'remark'       => '后台指派委卖',
                        'createtime'   => $now,
                        'updatetime'   => $now,
                    ]);
                }
            } else {
                // 1) 抢购订单（委卖中：卖方=会员，买方暂无）
                $orderId = Db::name('order')->insertGetId([
                    'order_no'     => 'BL' . date('YmdHis') . mt_rand(1000, 9999),
                    'type'         => 2,
                    'buyer_id'     => 0,
                    'seller_id'    => $userId,
                    'goods_id'     => $sg['goods_id'],
                    'subarea_id'   => $sg['subarea_id'],
                    'warehouse_id' => 0,
                    'amount'       => $price,
                    'pay_type'     => 0,
                    'pay_status'   => 2, // 已确认/已归属（用于业务阶段判定为委卖中）
                    'remark'       => '后台指派委卖',
                    'createtime'   => $now,
                    'updatetime'   => $now,
                ]);
                // 2) 卖方仓库（委卖中，带真实价格，避免前端显示 ¥0）
                $whId = Db::name('warehouse')->insertGetId([
                    'user_id'      => $userId,
                    'goods_id'     => $sg['goods_id'],
                    'subarea_id'   => $sg['subarea_id'],
                    'order_id'     => $orderId,
                    'sg_id'        => (int) $sg['id'],
                    'buy_price'    => $price,
                    'sell_price'   => $price,
                    'status'       => 2, // 委卖中
                    'selling_time' => $now,
                    'createtime'   => $now,
                    'updatetime'   => $now,
                ]);
                Db::name('order')->where('id', $orderId)->update(['warehouse_id' => $whId]);
            }
            // 按「行ID」精确记录归属会员（修复按商品名/goods_id 串号、新增即误显示已指派）
            Db::name('subarea_goods')->where('id', $sg['id'])->update(['user_id' => $userId, 'updatetime' => $now]);
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('指派失败：' . $e->getMessage());
        }
        $this->success('已指派给会员【' . ($user['nickname'] ?: $user['mobile']) . '】，已上架到本场抢购（委卖中），卖家可在「我的委卖订单」查看');
    }

}

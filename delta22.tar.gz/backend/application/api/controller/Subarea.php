<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\TeamService;
use think\Db;
use think\Exception;

/**
 * 抢购专区/场次 + 仓库/寄售 接口
 *
 * 业务流程：
 *  1) 抢单：会员在开放场次内对专区商品 buy 下单（向平台），生成"待支付"订单；
 *  2) 付款：买家 uploadPayment 上传付款凭证 → 订单"已支付待确认"；
 *  3) 确认：卖家/平台 confirm 确认收款 → 订单"已确认"，商品进入买家仓库，结算资金/收益；
 *  4) 寄售：买家把仓库商品 sellingWarehouse 按涨幅挂售，他人 buyWarehouse 买入（会员对会员，重复 2、3 步）；
 *  5) 换位 transposition：把持有商品调整到下一场次继续流转。
 *
 * 注：资金结算与团队分润比例已做成后台可配置（mall 配置），具体数值可在联调时按示例站调整。
 */
class Subarea extends Api
{
    protected $noNeedLogin = ['getSubarea', 'getGoodsList'];
    protected $noNeedRight = '*';

    /** 读取 mall 配置 */
    protected function conf($name, $default = '')
    {
        $v = Db::name('config')->where('name', $name)->value('value');
        return ($v === null || $v === '') ? $default : $v;
    }

    /** 是否新会员（注册时间在“新会员状态持续时间”分钟内，后台可配置；0=不启用） */
    protected function isNewMember($uid)
    {
        $minutes = (int) $this->conf('new_member_duration', 0);
        if ($minutes <= 0) {
            return false;
        }
        $u = Db::name('user')->where('id', $uid)->find();
        if (!$u) return false;
        $join = (int) ($u['jointime'] ?? $u['createtime'] ?? 0);
        return $join > 0 && (time() - $join) <= $minutes * 60;
    }

    /** 释放已过期未支付的抢购锁定，使商品重新回到寄售池（抢完未付→退回） */
    protected function releaseExpiredLocks($subareaId = 0)
    {
        $expiredOrders = Db::name('order')
            ->where('type', 2)->where('pay_status', 0)
            ->where('expire_time', '<', time())
            ->where('warehouse_id', '>', 0);
        if ($subareaId) {
            $expiredOrders->where('subarea_id', $subareaId);
        }
        $rows = $expiredOrders->select();
        foreach ($rows as $o) {
            // 订单作废
            Db::name('order')->where('id', $o['id'])->update(['pay_status' => 3, 'updatetime' => time()]);
            // 锁定商品退回委卖中
            Db::name('warehouse')->where('id', $o['warehouse_id'])->where('status', 4)
                ->update(['status' => 2, 'updatetime' => time()]);
        }
    }

    /** 分页参数 */
    protected function getPage()
    {
        $page = $this->request->request('page');
        $pageSize = $this->request->request('page_size');
        if ($page === null || $page === '') {
            $this->error('page不能为空');
        }
        if ($pageSize === null || $pageSize === '') {
            $this->error('page_size不能为空');
        }
        return [max(1, (int) $page), max(1, (int) $pageSize)];
    }

    /** 生成订单号 */
    protected function buildOrderNo()
    {
        return date('YmdHis') . str_pad(mt_rand(0, 99999), 5, '0', STR_PAD_LEFT);
    }

    /**
     * 计算场次当前状态与倒计时
     * @param array $row    场次记录
     * @param int   $advance 新会员可提前抢购的分钟数（默认0）
     * @return array [status(1未开始/2进行中/3已结束), countdown]
     */
    protected function calcStatus($row, $advance = 0)
    {
        $now = time();
        $todayStart = strtotime(date('Y-m-d', $now));
        $todaySec = $now - $todayStart;
        $start = (int) $row['start'] - max(0, (int) $advance) * 60; // 新会员提前量
        $end = (int) $row['end'];

        // 开启日期区间：超出区间则未开始/已结束
        $sd = (int) ($row['start_date'] ?? 0);
        $ed = (int) ($row['end_date'] ?? 0);
        if ($sd > 0) {
            $sdDay = strtotime(date('Y-m-d', $sd));
            if ($todayStart < $sdDay) {
                // 还没到开启日期 → 未开始，倒计时到首日开始时刻
                return [1, max(0, ($sdDay + $start) - $now)];
            }
        }
        if ($ed > 0) {
            $edDay = strtotime(date('Y-m-d', $ed));
            if ($todayStart > $edDay) {
                return [3, 0];
            }
        }

        if ($todaySec < $start) {
            return [1, $start - $todaySec];
        }
        if ($todaySec <= $end) {
            // 进行中：倒计时 = 距本场结束（end - now），真实递减，每个场次按各自结束时间独立
            return [2, max(0, $end - $todaySec)];
        }
        return [3, 0];
    }

    /**
     * 当前会员可享受的提前抢购分钟数。
     * 口径（对照示例站「会员等级」可设置「提前时间」）：优先按会员所属等级(user.group_id → user_group.advance_time)，
     * 未配置时兼容旧的「新会员提前量」全局配置。
     */
    protected function advanceMinutes($uid)
    {
        if (!$uid) {
            return 0;
        }
        // 会员专属抢购特权（优先级最高，覆盖等级提前时间）
        $priv = $this->userPrivilege($uid);
        if ($priv['active'] && $priv['advance_time'] > 0) {
            return $priv['advance_time'];
        }
        $gid = (int) Db::name('user')->where('id', $uid)->value('group_id');
        if ($gid) {
            $adv = Db::name('user_group')->where('id', $gid)->value('advance_time');
            if ($adv !== null && $adv !== '') {
                return max(0, (int) $adv);
            }
        }
        // 兼容旧配置：仅新会员享受全局提前量
        if ($this->isNewMember($uid)) {
            return (int) $this->conf('new_member_advance', 0);
        }
        return 0;
    }

    /**
     * 会员专属「抢购特权」（per-user，对照示例站会员编辑「抢购设置」）。
     * 开关开启且未过期（结束时间=0 视为永久）时生效，优先级最高。
     * @return array [active(bool), advance_time(int 提前分钟), advance_count(int 可抢上限/0=不限)]
     */
    protected function userPrivilege($uid)
    {
        $res = ['active' => false, 'advance_time' => 0, 'advance_count' => 0];
        if (!$uid) {
            return $res;
        }
        $u = Db::name('user')->where('id', $uid)->find();
        if (!$u || empty($u['advance_switch'])) {
            return $res; // 列不存在或开关关闭
        }
        $end = isset($u['advance_endtime']) ? (int) $u['advance_endtime'] : 0;
        if ($end > 0 && time() > $end) {
            return $res; // 特权已过期
        }
        $res['active'] = true;
        $res['advance_time'] = isset($u['advance_time']) ? max(0, (int) $u['advance_time']) : 0;
        $res['advance_count'] = isset($u['advance_count']) ? max(0, (int) $u['advance_count']) : 0;
        return $res;
    }

    /**
     * 读取会员所属「会员等级(user_group)」的抢购限制（对照示例站会员等级，交互联动）：
     *   - order_count   本场限购订单数（=0 表示该等级被「限制」，不可抢）
     *   - advance_time  提前开抢分钟数
     *   - advance_count 提前窗口内可抢数量
     * 各项返回 null 表示该等级未配置（回退场次配置）。
     * 会员专属特权开启时，以特权数量覆盖等级限制（优先级最高）。
     */
    protected function levelLimits($uid)
    {
        $res = ['order_count' => null, 'advance_time' => null, 'advance_count' => null];
        if (!$uid) {
            return $res;
        }
        $gid = (int) Db::name('user')->where('id', $uid)->value('group_id');
        // 未分配会员等级(group_id=0)时，按「默认等级」(最小ID的会员等级，通常为普通会员)兜底，
        //   使等级限购对所有会员生效（对照甲方反馈：王三普通用户应只能抢2单）。
        if ($gid <= 0) {
            $gid = (int) Db::name('user_group')->order('id asc')->value('id');
        }
        if ($gid) {
            $g = Db::name('user_group')->where('id', $gid)->find();
            if ($g) {
                foreach (array_keys($res) as $k) {
                    if (array_key_exists($k, $g) && $g[$k] !== null && $g[$k] !== '') {
                        $res[$k] = (int) $g[$k];
                    }
                }
            }
        }
        // 会员专属特权覆盖（优先级最高）：可抢数量同时作用于「本场限购」与「提前窗口可抢」
        $priv = $this->userPrivilege($uid);
        if ($priv['active']) {
            if ($priv['advance_time'] > 0) {
                $res['advance_time'] = $priv['advance_time'];
            }
            if ($priv['advance_count'] > 0) {
                $res['order_count'] = $priv['advance_count'];
                $res['advance_count'] = $priv['advance_count'];
            }
        }
        return $res;
    }

    /**
     * 校验会员本场抢购限制（与「会员等级」交互联动）。超限抛出异常。
     *   1) 等级 order_count = 本场限购数；=0 表示「限制」等级，直接禁止抢购。
     *      未配置等级时回退场次 new_count/user_count。
     *   2) 提前窗口内(now < 场次官方开始时刻)再按等级 advance_count 限制提前可抢数量。
     *   计数口径：本场该会员的全部购买订单（平台单 type=1 + 会员单 type=2）。
     * @param int   $uid
     * @param array $subarea 场次记录(含 id,start,new_count,user_count)
     * @param bool  $isNew
     * @throws Exception
     */
    protected function assertGrabLimit($uid, $subarea, $isNew)
    {
        $lv = $this->levelLimits($uid);
        $grabbed = Db::name('order')
            ->where('buyer_id', $uid)
            ->where('subarea_id', $subarea['id'])
            ->whereIn('type', [1, 2])
            ->whereIn('pay_status', [0, 1, 2])
            ->where('createtime', '>=', strtotime(date('Y-m-d')))
            ->count();

        // 会员等级「购买订单数量」：>0 即本场限购上限(对照后台会员等级配置说明「0=不限」)；
        //   =0 或未配置 → 回退场次配置(new_count/user_count)。
        if ($lv['order_count'] !== null && (int) $lv['order_count'] > 0) {
            $limit = (int) $lv['order_count'];
        } else {
            $limit = (int) ($isNew ? ($subarea['new_count'] ?? 1) : ($subarea['user_count'] ?? 1));
            if ($limit < 1) {
                $limit = 1;
            }
        }
        if ($grabbed >= $limit) {
            throw new Exception('本场抢购次数已用完（每人限' . $limit . '单）');
        }

        // 提前抢购窗口：当前时间早于场次官方开始时刻 → 受等级「提前抢购数量」限制
        if ($lv['advance_count'] !== null) {
            $todaySec = time() - strtotime(date('Y-m-d'));
            $officialStart = (int) ($subarea['start'] ?? 0);
            if ($todaySec < $officialStart && $grabbed >= (int) $lv['advance_count']) {
                throw new Exception('提前抢购数量已达上限（提前限' . (int) $lv['advance_count'] . '单）');
            }
        }
    }

    /**
     * 计算「本场」日期窗口 [起, 止]（秒级时间戳）
     * 对照示例站：抢购分场次，前端只展示「本场」商品 —— 即「添加时间」落在后台配置
     * 的开放日期区间(start_date~end_date)内的商品；未配置日期则默认「今天」。
     * 抢购板据此过滤仓库记录，历史/其他场次/已删除遗留的商品不再展示。
     * @param array $sub 场次记录
     * @return array [winStart, winEnd]
     */
    protected function sessionWindow($sub)
    {
        $sd = (int) ($sub['start_date'] ?? 0);
        $ed = (int) ($sub['end_date'] ?? 0);
        $winStart = $sd > 0 ? strtotime(date('Y-m-d', $sd)) : strtotime(date('Y-m-d'));
        $winEnd   = ($ed > 0 ? strtotime(date('Y-m-d', $ed)) : strtotime(date('Y-m-d'))) + 86399;
        return [$winStart, $winEnd];
    }

    /**
     * 专区/场次列表
     */
    public function getSubarea()
    {
        // 只返回已开启的场次（后台「配置」状态开关控制；场次就一个由后台配置）
        $uid = $this->auth->isLogin() ? $this->auth->id : 0;
        $advance = $this->advanceMinutes($uid);
        $lv = $this->levelLimits($uid);                 // 会员等级限制（交互联动）
        $isNew = $uid ? $this->isNewMember($uid) : false;
        $todayStart = strtotime(date('Y-m-d'));
        $list = Db::name('subarea')->where('status_switch', 1)->order('weigh desc,id asc')->select();
        foreach ($list as &$v) {
            list($status, $countdown) = $this->calcStatus($v, $advance);
            $v['status'] = $status;
            $v['countdown'] = $countdown;   // 距本场结束剩余秒数（进行中）或距开始（未开始）
            $v['server_time'] = time();
            $v['image'] = $v['image'] ? cdnurl($v['image'], true) : '';
            $v['status_switch_text'] = $v['status_switch'] ? '开启' : '关闭';
            $v['warehouse_switch_text'] = $v['warehouse_switch'] ? '开启' : '关闭';
            // ===== 会员等级限制信息（前端据此显示「可抢N单/已抢/限制不可抢」并联动按钮） =====
            // 会员等级「购买订单数量」>0 即本场限购(0=不限，回退场次配置)——与 assertGrabLimit 口径一致
            $limit = ($lv['order_count'] !== null && (int) $lv['order_count'] > 0)
                ? (int) $lv['order_count']
                : (int) ($isNew ? ($v['new_count'] ?? 1) : ($v['user_count'] ?? 1));
            $grabbed = $uid ? (int) Db::name('order')
                ->where('buyer_id', $uid)->where('subarea_id', $v['id'])
                ->whereIn('type', [1, 2])->whereIn('pay_status', [0, 1, 2])
                ->where('createtime', '>=', $todayStart)->count() : 0;
            $v['level_limit'] = $limit;                         // 本场限购数
            $v['level_grabbed'] = $grabbed;                     // 本场已抢数
            $v['level_remain'] = max(0, $limit - $grabbed);     // 剩余可抢
            $v['level_restricted'] = 0;                         // 限制等级(0=不限，取消按 order_count=0 判无权限)
            $v['advance_count'] = $lv['advance_count'] !== null ? (int) $lv['advance_count'] : 0;
        }
        $this->success('success', $list);
    }

    /**
     * 专区内商品列表
     */
    public function getGoodsList()
    {
        $id = (int) $this->request->request('id');
        $type = $this->request->request('type');
        if (!$id) {
            $this->error('id不能为空');
        }
        if ($type === null || $type === '') {
            $this->error('type不能为空');
        }
        list($page, $pageSize) = $this->getPage();
        // type=2「会员寄售」：返回真实的会员挂售中持仓（个人对个人互抢池），抢单走 buyWarehouse 付款给卖家本人
        // 对照示例站：抢完不是消失，而是保留并显示「已售完」。
        //   status=2 委卖中 → 可抢；status=4 抢购锁定/已被抢、status=3 已售出 → 已售完（保留展示，不可再抢）
        if ((int) $type === 2) {
            $uid = $this->auth->isLogin() ? $this->auth->id : 0;
            // 只展示「本场」商品：添加(挂售)时间落在后台配置的开放日期区间内，
            // 历史/其他场次/已删除遗留的商品不再显示（对照示例站「抢购分场次」）。
            $sub = Db::name('subarea')->where('id', $id)->find();
            list($winStart, $winEnd) = $this->sessionWindow($sub ?: []);
            $query = Db::name('warehouse')->alias('w')
                ->join('goods g', 'w.goods_id = g.id')
                ->join('user u', 'w.user_id = u.id')
                // 仅展示「委卖中(2,可抢)」与「抢购锁定(4,本轮刚被抢,显示已售完)」；
                // 已结算售出(3) 属于上一轮历史，不再带入本场，避免转售/二次开场时残留旧单
                // 与本轮重新挂售单重复显示（对照甲方反馈：第二场前端多出已售出的旧单）。
                ->where('w.subarea_id', $id)->whereIn('w.status', [2, 4])
                // 按「上架/挂售时间(selling_time)」归入本场：指派、会员挂售、换位都会刷新该时间，
                // 故只展示本场上架的商品；历史/其他场次/已删除遗留的不再展示。
                ->where('w.selling_time', 'between', [$winStart, $winEnd])
                ->field('w.id,w.subarea_id,w.goods_id,w.user_id,w.status,w.sell_price,w.buy_price,g.name,g.image,g.tags,g.price as goods_price,u.nickname');
            // 自己挂售的商品对自己隐藏（对照甲方：自己的单子看不见）
            if ($uid) {
                $query->where('w.user_id', '<>', $uid);
            }
            // 委卖中(可抢)排在前面，已售完沉底
            $res = $query->order('w.status asc,w.id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
            $list = $res->items();
            foreach ($list as &$v) {
                $v['image'] = $v['image'] ? cdnurl($v['image'], true) : '';
                $v['tags'] = $v['tags'] !== '' ? preg_split('/[,\s]+/', trim($v['tags'])) : [];
                // 价格兜底：委卖价→买入价→首页商品价，避免显示 ¥0
                $price = (float) $v['sell_price'];
                if ($price <= 0) $price = (float) $v['buy_price'];
                if ($price <= 0) $price = (float) $v['goods_price'];
                $v['price'] = $price;
                $sold = (int) $v['status'] !== 2;                 // 非「委卖中」= 已被抢走/已售完
                $isOwn = $uid && $v['user_id'] == $uid;            // 自己的商品不可抢
                $v['sold'] = $sold ? 1 : 0;                        // 1=已售完（保留展示，不消失）
                $v['stock'] = ($sold || $isOwn) ? 0 : 1;           // 0=不可抢
                $v['is_member'] = 1;
                $v['seller_name'] = $v['nickname'];
                $v['type'] = 2;
            }
            $this->success('success', ['list' => $list, 'total' => $res->total(), 'last_page' => $res->lastPage()]);
        }
        $query = Db::name('subarea_goods')->alias('sg')
            ->join('goods g', 'sg.goods_id = g.id')
            ->where('sg.subarea_id', $id)->where('sg.type', (int) $type)->where('sg.status', 1)
            ->field('sg.id,sg.subarea_id,sg.goods_id,sg.type,sg.price,sg.stock,g.name,g.image,g.tags');
        $res = $query->order('sg.weigh desc,sg.id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $list = $res->items();
        foreach ($list as &$v) {
            $v['image'] = $v['image'] ? cdnurl($v['image'], true) : '';
            $v['tags'] = $v['tags'] !== '' ? preg_split('/[,\s]+/', trim($v['tags'])) : [];
            $v['is_member'] = 0;
            $v['sold'] = (int) $v['stock'] <= 0 ? 1 : 0;   // 库存为0 → 已售完（保留展示）
        }
        $this->success('success', ['list' => $list, 'total' => $res->total(), 'last_page' => $res->lastPage()]);
    }

    /**
     * 订单/抢单详情
     */
    public function getInfo()
    {
        $id = (int) $this->request->request('id');
        $order = Db::name('order')->where('id', $id)->find();
        if (!$order) {
            $this->error('订单不存在');
        }
        $this->fillOrder($order);
        $this->success('success', $order);
    }

    /** 补充订单关联信息（商品、买卖家、收款方式） */
    protected function fillOrder(&$order)
    {
        $goods = Db::name('goods')->where('id', $order['goods_id'])->find();
        $order['goods_name'] = $goods['name'] ?? '';
        $order['goods_image'] = !empty($goods['image']) ? cdnurl($goods['image'], true) : '';
        $order['pay_voucher'] = $order['pay_voucher'] ? cdnurl($order['pay_voucher'], true) : '';
        $order['pay_status_text'] = [0 => '待支付', 1 => '已支付待确认', 2 => '已确认', 3 => '已取消'][$order['pay_status']] ?? '';
        $order['pay_type_text'] = [1 => '银行卡', 2 => '微信', 3 => '支付宝'][$order['pay_type']] ?? '';
        // 后台结算状态：0未结算（不可付款/不显示收款方式）1已结算待付款
        $order['settle_status'] = (int) ($order['settle_status'] ?? 0);
        // 订单业务状态（含“已入库/委卖中/已完成”，与示例站“我的订单”状态一致）
        $order['order_status'] = $this->orderStage($order);
        $order['order_status_text'] = [
            'unpaid'  => '待付款',
            'unconf'  => '待确认',
            'instock' => '已入库',
            'selling' => '委卖中',
            'done'    => '已完成',
            'cancel'  => '已取消',
        ][$order['order_status']] ?? '';
    }

    /**
     * 计算订单所处业务阶段
     * 待付款→待确认→已入库(商品在买家仓库持有)→委卖中(再次挂售)→已完成(已售出/已转手)
     */
    protected function orderStage($order)
    {
        $payStatus = (int) $order['pay_status'];
        if ($payStatus === 0) return 'unpaid';
        if ($payStatus === 1) return 'unconf';
        if ($payStatus === 3) return 'cancel';
        // 已确认：看本次抢单生成的仓库记录现状
        $wh = Db::name('warehouse')->where('order_id', $order['id'])->order('id desc')->find();
        if (!$wh) return 'done';
        $map = [1 => 'instock', 2 => 'selling', 3 => 'done'];
        return $map[(int) $wh['status']] ?? 'instock';
    }

    /**
     * 构建「差价付款单」前端展示结构（结算页 / 我的订单 / 买卖方分区通用）
     *   role=pay     我是付款人(本场购入)→可上传付款凭证
     *   role=collect 我是收款人(本场出售)→对方付款后可确认收款
     */
    protected function buildPayItem($p, $uid)
    {
        $statusText = [0 => '待支付', 1 => '已支付待确认', 2 => '已确认', 3 => '已取消'];
        $kindText   = [1 => '商品差价', 2 => '上架费'];
        $price  = (float) $p['price'];
        $status = (int) $p['pay_status'];
        $isCollector = ((int) $p['collect_user_id'] === (int) $uid);
        $cpId   = $isCollector ? (int) $p['user_id'] : (int) $p['collect_user_id'];
        $cpName = $cpId
            ? (Db::name('user')->where('id', $cpId)->value('nickname') ?: ('会员' . $cpId))
            : '公司财务';
        return [
            'id'          => (int) $p['id'],
            'is_diff'     => 1,
            'order_id'    => (int) ($p['order_id'] ?? 0),
            'subarea_id'  => (int) $p['subarea_id'],
            'kind'        => (int) $p['kind'],
            'kind_text'   => $kindText[(int) $p['kind']] ?? '商品差价',
            'amount'      => $price,
            'pay_amount'  => $price,
            'pay_type'    => (int) $p['pay_type'],
            'pay_voucher' => $p['image'] ? cdnurl($p['image'], true) : '',
            'status'      => $status,
            'status_text' => $statusText[$status] ?? '',
            'update_time' => date('Y-m-d H:i:s', $p['updatetime'] ?: $p['createtime']),
            'role'        => $isCollector ? 'collect' : 'pay',
            'name'        => $cpName,
            'can_pay'     => (!$isCollector && $status === 0) ? 1 : 0,
            'can_confirm' => ($isCollector && $status === 1) ? 1 : 0,
        ];
    }

    /**
     * 本场某会员真实买入/卖出的商品（结算页「本场出售/本场购入」展示用）
     * @param int  $subareaId 场次
     * @param int  $uid       会员
     * @param bool $asSeller  true=我卖出(本场出售) false=我买入(本场购入)
     */
    protected function sessionGoods($subareaId, $uid, $asSeller)
    {
        $q = Db::name('order')->alias('o')
            ->join('goods g', 'o.goods_id = g.id', 'LEFT')
            // 排除上架费(pay_kind=2)；抢购订单 pay_kind 可能为 NULL，需一并保留（NULL<>2 在SQL里不成立会误删）
            ->whereRaw('(o.pay_kind IS NULL OR o.pay_kind <> 2)');
        if ($subareaId > 0) {
            // 0=聚合全部场次（我的→买入/委卖订单入口）；>0=指定场次
            $q->where('o.subarea_id', $subareaId);
        }
        if ($asSeller) {
            // 本场出售：我作为卖家被他人买走（会员转手 type=2）
            $q->where('o.type', 2)->where('o.seller_id', $uid)->where('o.buyer_id', '>', 0);
        } else {
            // 本场购入：我买入的商品（含平台抢购 type=1 与会员转手 type=2），均作为「相关商品」展示
            $q->where('o.buyer_id', $uid)->where('o.type', 'in', [1, 2]);
        }
        $rows = $q->field('o.id,o.order_no,o.amount,o.createtime,o.pay_status,g.name,g.image')
            ->order('o.id desc')->select();
        $statusText = [0 => '待付款', 1 => '已支付待确认', 2 => '已确认', 3 => '已取消'];
        $out = [];
        foreach ($rows as $r) {
            $out[] = [
                // order_id：供结算页把「相关商品」与「付款单(差价/全额)」按订单严格对齐，
                //   避免按下标配对导致金额错位（甲方反馈的「两单金额正好反了」）。
                'order_id'    => (int) $r['id'],
                'order_no'    => $r['order_no'],
                'goods_name'  => $r['name'] ?? '',
                'goods_image' => !empty($r['image']) ? cdnurl($r['image'], true) : '',
                'amount'      => (float) $r['amount'],
                'status_text' => $statusText[(int) $r['pay_status']] ?? '',
                'create_time' => date('Y-m-d H:i:s', $r['createtime']),
            ];
        }
        return $out;
    }

    /**
     * 按付款单顺序取「相关商品」，与付款单严格一一对齐（简化转售模式结算页专用）。
     *   每张付款单(order_id)→对应抢购订单→商品，保证商品价与支付金额一一对应，绝不错位。
     *   历史数据无 order_id 时，退化为用付款金额占位（金额仍正确，只是缺商品图/名）。
     * @param array $items buildPayItem() 产出的付款单数组（sell 或 buy）
     */
    protected function payItemsGoods($items)
    {
        $statusText = [0 => '待付款', 1 => '已支付待确认', 2 => '已确认', 3 => '已取消'];
        $out = [];
        foreach ($items as $it) {
            $oid = (int) ($it['order_id'] ?? 0);
            $g = null;
            if ($oid > 0) {
                $g = Db::name('order')->alias('o')
                    ->join('goods g', 'o.goods_id = g.id', 'LEFT')
                    ->where('o.id', $oid)
                    ->field('o.order_no,o.amount,o.createtime,o.pay_status,g.name,g.image')
                    ->find();
            }
            if ($g) {
                $out[] = [
                    'order_no'    => $g['order_no'],
                    'goods_name'  => $g['name'] ?? '',
                    'goods_image' => !empty($g['image']) ? cdnurl($g['image'], true) : '',
                    'amount'      => (float) $g['amount'],
                    'status_text' => $statusText[(int) $g['pay_status']] ?? '',
                    'create_time' => date('Y-m-d H:i:s', $g['createtime']),
                ];
            } else {
                // 兜底：无关联订单，用付款金额占位，保证金额不错配
                $out[] = [
                    'order_no'    => '',
                    'goods_name'  => '',
                    'goods_image' => '',
                    'amount'      => (float) ($it['pay_amount'] ?? $it['amount'] ?? 0),
                    'status_text' => $it['status_text'] ?? '',
                    'create_time' => $it['update_time'] ?? '',
                ];
            }
        }
        return $out;
    }

    /**
     * 抢单（向平台购买专区商品）
     * @param int $subarea_goods_id 专区商品ID
     */
    public function buy()
    {
        $sgId = (int) $this->request->post('subarea_goods_id', $this->request->post('id'));
        $payType = (int) $this->request->post('pay_type', 1);
        if (!$sgId) {
            $this->error('参数不正确');
        }
        $uid = $this->auth->id;
        Db::startTrans();
        try {
            $sg = Db::name('subarea_goods')->where('id', $sgId)->lock(true)->find();
            if (!$sg || $sg['status'] != 1) {
                throw new Exception('商品不存在或已下架');
            }
            $subarea = Db::name('subarea')->where('id', $sg['subarea_id'])->find();
            if (!$subarea || !$subarea['status_switch']) {
                throw new Exception('当前场次未开放抢单');
            }
            $isNew = $this->isNewMember($uid);
            list($st) = $this->calcStatus($subarea, $this->advanceMinutes($uid));
            if ($st != 2) {
                throw new Exception('不在抢单时间内');
            }
            if ($sg['stock'] <= 0) {
                throw new Exception('已被抢完');
            }
            // 抢购限制（与会员等级交互联动：限购数 / 限制等级 / 提前抢购数量）
            $this->assertGrabLimit($uid, $subarea, $isNew);
            // 扣库存：行锁(lock true)已串行化并发抢购，此处再加「库存>0」条件原子自减，
            //   双保险确保多人同时抢同一商品绝不超卖（只有抢到库存的那一次 affected=1）。
            $affected = Db::name('subarea_goods')->where('id', $sgId)->where('stock', '>', 0)->setDec('stock');
            if (!$affected) {
                throw new Exception('已被抢完');
            }
            $countdownMin = (int) $this->conf('pay_countdown', 15);
            $orderId = Db::name('order')->insertGetId([
                'order_no'    => $this->buildOrderNo(),
                'type'        => 1,
                'buyer_id'    => $uid,
                'seller_id'   => 0, // 平台
                'goods_id'    => $sg['goods_id'],
                'subarea_id'  => $sg['subarea_id'],
                'warehouse_id' => 0,
                'amount'      => $sg['price'],
                'pay_type'    => $payType,
                'pay_status'  => 0,
                'expire_time' => time() + $countdownMin * 60,
                'createtime'  => time(),
                'updatetime'  => time(),
            ]);
            Db::commit();
            $this->success('抢单成功', ['order_id' => $orderId]);
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 从他人仓库买入（会员对会员的寄售交易）
     * @param int $warehouse_id 挂售中的仓库记录ID
     */
    /**
     * 抢单前置约束检查：返回会员是否已签约 / 已设置收款方式 / 已添加收货地址
     * 前端抢单前调用，缺项时弹窗提示（对照示例站抢单约束）
     * @return array [signed, has_pay, has_address, ready, missing[]]
     */
    protected function checkGrabConstraint($uid)
    {
        // 已签约：存在签约记录且「审核通过(status=1) + 签名通过(sign_status=1)」
        //   对照甲方要求：后台签名没通过，前端也不能抢购。
        $signed = Db::name('signing')->where('user_id', $uid)
            ->where('status', 1)->where('sign_status', 1)->count() > 0;
        // 已设置收款方式：user_pay 中至少配置一种(银行卡/微信/支付宝)
        $pay = Db::name('user_pay')->where('user_id', $uid)->find();
        $hasPay = $pay && (
            !empty($pay['card_account']) || !empty($pay['wx_account']) || !empty($pay['wx_image'])
            || !empty($pay['zfb_account']) || !empty($pay['zfb_image'])
        );
        // 已添加收货地址
        $hasAddress = Db::name('address')->where('user_id', $uid)->count() > 0;
        $missing = [];
        if (!$signed)     $missing[] = '完成实名签约并通过后台签名审核';
        if (!$hasPay)     $missing[] = '设置收款方式';
        if (!$hasAddress) $missing[] = '添加收货地址';
        return [
            'signed'      => $signed ? 1 : 0,
            'has_pay'     => $hasPay ? 1 : 0,
            'has_address' => $hasAddress ? 1 : 0,
            'ready'       => empty($missing) ? 1 : 0,
            'missing'     => $missing,
        ];
    }

    /**
     * 抢单前置约束状态查询（前端弹窗用）
     */
    public function grabReady()
    {
        $this->success('success', $this->checkGrabConstraint($this->auth->id));
    }

    public function buyWarehouse()
    {
        $wid = (int) $this->request->post('warehouse_id', $this->request->post('id'));
        $payType = (int) $this->request->post('pay_type', 1);
        if (!$wid) {
            $this->error('参数不正确');
        }
        $uid = $this->auth->id;
        // 抢单约束：未签约 / 无收款方式 / 无收货地址 不能抢单（服务端强校验）
        $constraint = $this->checkGrabConstraint($uid);
        if (!$constraint['ready']) {
            $this->error('抢单前请先：' . implode('、', $constraint['missing']), $constraint);
        }
        Db::startTrans();
        try {
            $wh = Db::name('warehouse')->where('id', $wid)->lock(true)->find();
            if (!$wh || $wh['status'] != 2) {
                // 已被他人抢走 → 委卖中(2)以外都视为抢完即消失
                throw new Exception('手慢了，该商品已被抢走');
            }
            if ($wh['user_id'] == $uid) {
                throw new Exception('不能抢自己的商品');
            }
            $subarea = Db::name('subarea')->where('id', $wh['subarea_id'])->find();
            if (!$subarea || !$subarea['status_switch']) {
                throw new Exception('当前场次未开放抢单');
            }
            $isNew = $this->isNewMember($uid);
            list($st) = $this->calcStatus($subarea, $this->advanceMinutes($uid));
            if ($st != 2) {
                throw new Exception('不在抢单时间内');
            }
            // 抢购限制（与会员等级交互联动：限购数 / 限制等级 / 提前抢购数量）
            $this->assertGrabLimit($uid, $subarea, $isNew);
            // 抢中即锁定：商品状态置 4(抢购锁定)，从寄售池消失，归属本次买家。
            //   行锁(lock true)已串行化并发；此处再以「status=2」为条件原子更新，
            //   多人同时抢同一件时只有第一个人 affected=1 抢到，其余抛「已被抢走」——绝不多抢。
            $locked = Db::name('warehouse')->where('id', $wid)->where('status', 2)->update([
                'status'     => 4,
                'updatetime' => time(),
            ]);
            if (!$locked) {
                throw new Exception('手慢了，该商品已被抢走');
            }
            $countdownMin = (int) $this->conf('pay_countdown', 15);
            // 售价兜底：避免委卖价为 0 时订单金额为 0
            $sellPrice = (float) $wh['sell_price'];
            if ($sellPrice <= 0) {
                $sellPrice = (float) $wh['buy_price'];
            }
            // 后台「指派委卖」会预先生成一条占位订单（seller=卖家, buyer=0, 委卖中）。
            //   抢购时复用该占位订单 → 卖家「我的委卖订单」中同一单子流转：委卖中→待付款→待确认→已确认，
            //   避免出现两条订单，且卖家可对其确认付款。前端用户挂售无占位订单则新建。
            $placeholder = Db::name('order')
                ->where('warehouse_id', $wid)
                ->where('seller_id', $wh['user_id'])
                ->where('buyer_id', 0)
                ->order('id desc')->find();
            if ($placeholder) {
                Db::name('order')->where('id', $placeholder['id'])->update([
                    'buyer_id'      => $uid,
                    'amount'        => $sellPrice,
                    'pay_type'      => $payType,
                    'pay_status'    => 0,
                    'settle_status' => 0,
                    'expire_time'   => time() + $countdownMin * 60,
                    'remark'        => '抢购成交',
                    'createtime'    => time(), // 以实际抢中时间为下单时间（用于本场限购计数与展示）
                    'updatetime'    => time(),
                ]);
                $orderId = $placeholder['id'];
            } else {
                $orderId = Db::name('order')->insertGetId([
                    'order_no'    => $this->buildOrderNo(),
                    'type'        => 2,
                    'buyer_id'    => $uid,
                    'seller_id'   => $wh['user_id'],
                    'goods_id'    => $wh['goods_id'],
                    'subarea_id'  => $wh['subarea_id'],
                    'warehouse_id' => $wid,
                    'amount'      => $sellPrice,
                    'pay_type'    => $payType,
                    'pay_status'  => 0,
                    'expire_time' => time() + $countdownMin * 60,
                    'createtime'  => time(),
                    'updatetime'  => time(),
                ]);
            }
            Db::commit();
            $this->success('抢单成功', ['order_id' => $orderId]);
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 上传付款凭证
     * @param int $order_id 订单ID
     * @param string $voucher 凭证图片地址
     */
    public function uploadPayment()
    {
        $orderId = (int) $this->request->post('order_id', $this->request->post('id'));
        $voucher = $this->request->post('voucher', $this->request->post('pay_voucher'));
        $payType = (int) $this->request->post('pay_type', 0);
        if (!$orderId || !$voucher) {
            $this->error('请上传付款凭证');
        }
        $order = Db::name('order')->where('id', $orderId)->where('buyer_id', $this->auth->id)->find();
        if (!$order) {
            $this->error('订单不存在');
        }
        if ($order['pay_status'] != 0) {
            $this->error('该订单无需重复上传');
        }
        // 必须等后台结算完成后才能上传付款凭证（对照示例站流程：抢单→后台结算→付款）
        if ((int) ($order['settle_status'] ?? 0) !== 1) {
            $this->error('请等待后台结算完成后再上传付款凭证');
        }
        $update = [
            'pay_voucher' => preg_replace('#^https?://[^/]+#', '', $voucher),
            'pay_status'  => 1,
            'pay_time'    => time(),
            'updatetime'  => time(),
        ];
        if ($payType) {
            $update['pay_type'] = $payType;
        }
        Db::name('order')->where('id', $orderId)->update($update);
        $this->success('上传成功，等待卖家确认收款');
    }

    /**
     * 确认收款（卖家/平台确认）→ 完成交易、结算
     * @param int $order_id 订单ID
     */
    public function confirm()
    {
        $orderId = (int) $this->request->post('order_id', $this->request->post('id'));
        if (!$orderId) {
            $this->error('参数不正确');
        }
        $uid = $this->auth->id;
        Db::startTrans();
        try {
            $order = Db::name('order')->where('id', $orderId)->lock(true)->find();
            if (!$order) {
                throw new Exception('订单不存在');
            }
            // 平台单允许买家自身确认收货；会员单需卖家确认
            if ($order['type'] == 2 && $order['seller_id'] != $uid) {
                throw new Exception('只有收款方可确认');
            }
            if ($order['pay_status'] != 1) {
                throw new Exception('当前订单状态不可确认');
            }
            $this->settleOrder($order);
            Db::name('order')->where('id', $orderId)->update([
                'pay_status'   => 2,
                'confirm_time' => time(),
                'updatetime'   => time(),
            ]);
            Db::commit();
            $this->success('确认成功');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /**
     * 订单结算：商品转入买家仓库 + 卖家收益 + 团队分润
     * （核心逻辑统一收敛到 OrderService，前后台共用）
     */
    protected function settleOrder($order)
    {
        \app\common\library\OrderService::settle($order);
    }

    /**
     * 挂售（把仓库持有商品按涨幅上架寄售）
     * @param int $warehouse_id
     * @param float $sell_price 可选自定义售价
     */
    public function sellingWarehouse()
    {
        $wid = (int) $this->request->post('warehouse_id', $this->request->post('id'));
        $customPrice = $this->request->post('sell_price');
        $feeVoucher = $this->request->post('fee_voucher', $this->request->post('voucher'));
        $payType = (int) $this->request->post('pay_type', 1);
        if (!$wid) {
            $this->error('参数不正确');
        }
        $wh = Db::name('warehouse')->where('id', $wid)->where('user_id', $this->auth->id)->find();
        if (!$wh) {
            $this->error('仓库记录不存在');
        }
        if ((int) $wh['status'] != 1) {
            $this->error('该商品当前不可挂售');
        }
        $increaseFee = (float) $this->conf('increaseFee', 0);
        $listingFee = (float) $this->conf('listingFee', 0);
        // 转售价：仅当传入「有效正数」自定义价时采用；否则按「买价 ×(1+交易利益比%)」自动计算
        // （对照示例站：转售价=买价+3%溢价，如 1000→1030）。
        $sellPrice = (is_numeric($customPrice) && (float) $customPrice > 0)
            ? round((float) $customPrice, 2)
            : round((float) $wh['buy_price'] * (1 + $increaseFee / 100), 2);
        // 上架费 = 转售价 × 手续费%（与前端弹窗展示口径一致）
        $feeAmount = round($sellPrice * $listingFee / 100, 2);
        // 上架费：配置了上架费(listingFee>0)时，必须先上传上架费支付凭证。
        //   前端用户「不能自己完成上架」，只能提交凭证 → 进入后台付款订单审核，后台再批量上架。
        if ($listingFee > 0 && empty($feeVoucher)) {
            $this->error('请先上传上架费支付凭证', ['need_fee' => 1, 'listingFee' => $listingFee, 'fee_amount' => $feeAmount]);
        }
        Db::startTrans();
        try {
            $now = time();
            $feeVoucherPath = !empty($feeVoucher) ? preg_replace('#^https?://[^/]+#', '', $feeVoucher) : '';
            // 1) 仓库置「待上架(挂售待审核=5)」：暂不进入抢购板，等后台审核上架费并批量上架后才上架
            Db::name('warehouse')->where('id', $wid)->update([
                'status'      => 5,        // 待上架（挂售待审核）
                'sell_price'  => $sellPrice,
                'fee'         => $feeAmount,
                'fee_voucher' => $feeVoucherPath,
                'updatetime'  => $now,
            ]);
            // 2) 委卖占位订单：让后台「抢购订单」可见并可批量上架（buyer=0，已归属委卖；商品付款类型）
            $placeholder = Db::name('order')
                ->where('warehouse_id', $wid)->where('seller_id', $this->auth->id)
                ->where('buyer_id', 0)->order('id desc')->find();
            if ($placeholder) {
                Db::name('order')->where('id', $placeholder['id'])->update([
                    'amount'     => $sellPrice, 'pay_status' => 2, 'pay_kind' => 1,
                    'remark'     => '会员挂售待上架', 'createtime' => $now, 'updatetime' => $now,
                ]);
            } else {
                Db::name('order')->insert([
                    'order_no'     => 'SL' . date('YmdHis') . mt_rand(1000, 9999),
                    'type'         => 2, 'buyer_id' => 0, 'seller_id' => $this->auth->id,
                    'goods_id'     => $wh['goods_id'], 'subarea_id' => $wh['subarea_id'],
                    'warehouse_id' => $wid, 'amount' => $sellPrice, 'pay_type' => 0,
                    'pay_status'   => 2, 'pay_kind' => 1, 'remark' => '会员挂售待上架',
                    'createtime'   => $now, 'updatetime' => $now,
                ]);
            }
            // 3) 上架费付款单：进入后台「付款订单」列表（付款类型=上架费付款，已支付待确认），等后台审核
            if ($feeAmount > 0 || $feeVoucherPath !== '') {
                Db::name('order')->insert([
                    'order_no'     => 'FE' . date('YmdHis') . mt_rand(1000, 9999),
                    'type'         => 2, 'buyer_id' => $this->auth->id, 'seller_id' => 0,
                    'goods_id'     => $wh['goods_id'], 'subarea_id' => $wh['subarea_id'],
                    'warehouse_id' => $wid, 'amount' => $feeAmount, 'pay_type' => $payType,
                    'pay_status'   => 1, 'pay_kind' => 2,  // 上架费付款
                    'pay_voucher'  => $feeVoucherPath, 'pay_time' => $now,
                    'remark'       => '上架费付款', 'createtime' => $now, 'updatetime' => $now,
                ]);
            }
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error('提交失败：' . $e->getMessage());
        }
        $this->success('已提交上架申请，待后台审核上架费后上架', ['sell_price' => $sellPrice, 'fee_amount' => $feeAmount]);
    }

    /**
     * 转售（简化转售模式 biz_mode=1）：
     *   买家在「买方仓库」对已开启转售(resell=1)且处于持有(status=1)的商品点「转售」，
     *   商品直接进入「委卖中(status=2)」，按溢价比例(increaseFee)自动定挂售价，并生成委卖抢购单；
     *   买方仓库不再显示该单，卖方「委卖订单」显示委卖中。
     *   时间窗口：开启转售当天 24:00 前可点；跨过 0 点未点则失效，需后台次日重新开启。
     * @param int $warehouse_id
     */
    public function resell()
    {
        if ((int) $this->conf('biz_mode', 0) !== 1) {
            $this->error('当前非简化转售模式');
        }
        $wid = (int) $this->request->post('warehouse_id', $this->request->post('id'));
        if ($wid <= 0) {
            $this->error('参数不正确');
        }
        Db::startTrans();
        try {
            $wh = Db::name('warehouse')->where('id', $wid)->where('user_id', $this->auth->id)->lock(true)->find();
            if (!$wh) {
                throw new Exception('仓库记录不存在');
            }
            if ((int) $wh['status'] !== 1) {
                throw new Exception('该商品当前不可转售');
            }
            if ((int) ($wh['resell'] ?? 0) !== 1) {
                throw new Exception('该商品尚未开启转售，请等待后台开启');
            }
            // 时间窗口：开启转售当天 24:00 前有效；跨天失效需后台重新开启
            $rt = (int) ($wh['resell_time'] ?? 0);
            if ($rt > 0 && date('Y-m-d', $rt) !== date('Y-m-d')) {
                Db::name('warehouse')->where('id', $wid)->update(['resell' => 0, 'updatetime' => time()]);
                throw new Exception('转售已过当日有效期，请等待后台次日重新开启');
            }
            $increaseFee = (float) $this->conf('increaseFee', 0);
            $sellPrice = round((float) $wh['buy_price'] * (1 + $increaseFee / 100), 2);
            $now = time();
            // 进入委卖中(2)，按溢价挂售价，关闭转售开关
            Db::name('warehouse')->where('id', $wid)->update([
                'status'       => 2,
                'sell_price'   => $sellPrice,
                'selling_time' => $now,
                'resell'       => 0,
                'updatetime'   => $now,
            ]);
            // 同步商品挂售价
            $sg = Db::name('subarea_goods')
                ->where('goods_id', $wh['goods_id'])
                ->where('subarea_id', $wh['subarea_id'])
                ->where('user_id', $wh['user_id'])
                ->order('id desc')->find();
            if ($sg) {
                Db::name('subarea_goods')->where('id', $sg['id'])->update(['price' => $sellPrice, 'updatetime' => $now]);
            }
            // 生成委卖抢购单（卖方=当前持有会员，买方=空），等待他人抢购
            $placeholder = Db::name('order')->where('warehouse_id', $wid)
                ->where('seller_id', $this->auth->id)->where('buyer_id', 0)->order('id desc')->find();
            if ($placeholder) {
                Db::name('order')->where('id', $placeholder['id'])->update([
                    'amount' => $sellPrice, 'pay_status' => 0, 'settle_status' => 0, 'updatetime' => $now,
                ]);
            } else {
                Db::name('order')->insert([
                    'order_no'      => 'RS' . date('YmdHis') . mt_rand(1000, 9999),
                    'type'          => 2, 'buyer_id' => 0, 'seller_id' => $this->auth->id,
                    'goods_id'      => (int) $wh['goods_id'], 'subarea_id' => (int) $wh['subarea_id'],
                    'warehouse_id'  => $wid, 'amount' => $sellPrice, 'pay_type' => 0,
                    'pay_status'    => 0, 'settle_status' => 0, 'remark' => '会员转售挂售',
                    'createtime'    => $now, 'updatetime' => $now,
                ]);
            }
            Db::commit();
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
        $this->success('转售成功，商品已进入委卖中');
    }

    /**
     * 我的仓库
     */
    public function myWarehouse()
    {
        list($page, $pageSize) = $this->getPage();
        $status = $this->request->request('status');
        $query = Db::name('warehouse')->alias('w')
            ->join('goods g', 'w.goods_id = g.id')
            ->where('w.user_id', $this->auth->id)
            ->field('w.*,g.name,g.image,g.tags');
        if ($status !== null && $status !== '') {
            // 卖仓(status=2)同时纳入「待上架(5)」：会员已提交挂售、等后台审核上架费上架
            if ((int) $status === 2) {
                $query->whereIn('w.status', [2, 5]);
            } else {
                $query->where('w.status', (int) $status);
            }
        }
        $res = $query->order('w.id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $list = $res->items();
        $today = date('Y-m-d');
        foreach ($list as &$v) {
            $v['image'] = $v['image'] ? cdnurl($v['image'], true) : '';
            $v['status_text'] = [1 => '待转售', 2 => '委卖中', 3 => '已售出', 5 => '待上架(审核中)'][$v['status']] ?? '';
            // 简化转售模式：持有(1) + 已开启转售(resell=1) + 当日有效 → 显示「转售」按钮
            $rt = (int) ($v['resell_time'] ?? 0);
            $v['can_resell'] = ((int) $v['status'] === 1
                && (int) ($v['resell'] ?? 0) === 1
                && ($rt === 0 || date('Y-m-d', $rt) === $today)) ? 1 : 0;
        }
        $this->success('success', ['list' => $list, 'total' => $res->total(), 'last_page' => $res->lastPage()]);
    }

    /**
     * 仓库商品详情
     */
    public function myWarehouseInfo()
    {
        $id = (int) $this->request->request('id');
        $wh = Db::name('warehouse')->alias('w')->join('goods g', 'w.goods_id = g.id')
            ->where('w.id', $id)->field('w.*,g.name,g.image,g.tags,g.content')->find();
        if (!$wh) {
            $this->error('记录不存在');
        }
        $wh['image'] = $wh['image'] ? cdnurl($wh['image'], true) : '';
        $wh['status_text'] = [1 => '待转售', 2 => '委卖中', 3 => '已售出', 5 => '待上架(审核中)'][$wh['status']] ?? '';
        $this->success('success', $wh);
    }

    /**
     * 我的抢购订单
     */
    public function getOrder()
    {
        list($page, $pageSize) = $this->getPage();
        $status = $this->request->request('status');
        $tab = $this->request->request('tab');   // 业务标签：unpaid/unconf/instock/done
        $role = $this->request->request('role'); // buy=只买入(买方) sell=只卖出(卖方) 空=全部
        $uid = $this->auth->id;
        // 包含：作为买家的订单 + 作为卖家的全部订单（委卖中/被抢待确认等）
        //   修复：被买家抢走的委卖单(buyer_id≠0)此前不在卖家「我的委卖订单」中显示，
        //   导致卖家无法「确认付款」。现卖家可见其全部 seller_id 订单。
        //   买方/卖方分区：role=buy 只看买入；role=sell 只看卖出（对照甲方「我的」页买卖方分区）。
        $query = Db::name('order')->where(function ($q) use ($uid, $role) {
            if ($role === 'buy') {
                $q->where('buyer_id', $uid);
            } elseif ($role === 'sell') {
                $q->where('seller_id', $uid);
            } else {
                $q->where('buyer_id', $uid)->whereOr('seller_id', $uid);
            }
        })->where('pay_kind', '<>', 2) // 排除「上架费付款」单，只展示商品交易订单
            ->where('buyer_id', '>', 0); // 排除「委卖中占位单(buyer=0)」——后台加仓/挂售生成的占位单不进「我的订单」(对照甲方：加仓的单子不显示待付款)
        // 优先按业务标签筛选（对照示例站“我的订单”分页：全部/待付款/待确认/已入库/已完成）
        if ($tab !== null && $tab !== '' && $tab !== 'all') {
            if ($tab === 'unpaid') {
                // 待付款 = 我作为「买家」需要支付的单（卖家视角的未付款属于「待收款」，不在此列）
                $query->where('pay_status', 0)->where('buyer_id', $uid);
            } elseif ($tab === 'unconf') {
                $query->where('pay_status', 1);
            } elseif ($tab === 'instock') {
                // 已入库：已确认且对应仓库记录仍在“持有/委卖中”
                $ids = Db::name('warehouse')->where('user_id', $uid)->whereIn('status', [1, 2])->column('order_id');
                $ids = array_filter($ids);
                $query->where('pay_status', 2)->whereIn('id', $ids ?: [0]);
            } elseif ($tab === 'done') {
                // 已完成：已确认且对应仓库已售出，或无关联仓库
                $soldIds = Db::name('warehouse')->where('user_id', $uid)->where('status', 3)->column('order_id');
                $soldIds = array_filter($soldIds);
                $query->where('pay_status', 2)->where(function ($q) use ($soldIds) {
                    $q->whereIn('id', $soldIds ?: [0]);
                });
            }
        } elseif ($status !== null && $status !== '') {
            $query->where('pay_status', (int) $status);
        }
        $res = $query->order('id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $list = $res->items();
        foreach ($list as &$v) {
            $this->fillOrder($v);
        }
        unset($v);

        // 「已完成」严格按业务阶段(order_status)过滤：仅保留真正已完成单，排除仍处于「委卖中」等未完成单
        //   （修复甲方反馈：卖方「已完成」里出现委卖中的单）
        if ($tab === 'done') {
            $list = array_values(array_filter($list, function ($v) {
                return ($v['order_status'] ?? '') === 'done';
            }));
        }

        // 差价付款单（结算后生成）：按「待付款/待收款」语义附带，前端在列表下方展示并支持操作
        //   买方/全部 + 待付款 → 我应付的差价（可上传付款凭证）
        //   卖方 + 待收款(unconf) → 别人应付我的差价(已付待确认，可确认收款)；done → 已确认
        //   注意：上架费(kind=2)不在「我的订单」展示（对照甲方：这块不应该有上架费），
        //   上架费只在「结算 → 本场购入」里由会员上传凭证。此处只取商品差价(kind=1)。
        $diffs = [];
        if ($role === 'sell') {
            $st = ($tab === 'done') ? [2] : [1];
            $rows = Db::name('pay_order')->where('collect_user_id', $uid)->where('kind', 1)
                ->whereIn('pay_status', $st)->order('id desc')->select();
            foreach ($rows as $p) {
                $diffs[] = $this->buildPayItem($p, $uid);
            }
        } elseif ($tab === 'unpaid' || $tab === '' || $tab === null || $tab === 'all' || $tab === 'done') {
            $st = ($tab === 'done') ? [2] : [0];
            $rows = Db::name('pay_order')->where('user_id', $uid)->where('kind', 1)
                ->whereIn('pay_status', $st)->order('id desc')->select();
            foreach ($rows as $p) {
                $diffs[] = $this->buildPayItem($p, $uid);
            }
        }

        // 差价视图：买方/卖方分区的「待付款/已付款/待收款/已收款」以及「待付款」标签，
        //   只展示「差价付款单」(结算后生成的净差价)，不再混入全价抢购/委卖单。
        //   对照甲方反馈：
        //     - 王三本场是「收款方」，买方待付款里不应出现他的 5000 全价单；
        //     - 后台加仓的单子不应显示为「待付款」(加仓商品只进卖方「委卖中」)。
        if (in_array($role, ['buy', 'sell'], true) || $tab === 'unpaid') {
            $list = [];
        }

        $this->success('success', [
            'list'      => $list,
            'total'     => $res->total(),
            'last_page' => $res->lastPage(),
            'diffs'     => $diffs,
        ]);
    }

    /**
     * 订单详情（买家视角，含卖家收款信息）
     */
    public function getBuyOrderDetail()
    {
        $id = (int) $this->request->request('id');
        $order = Db::name('order')->where('id', $id)->find();
        if (!$order) {
            $this->error('订单不存在');
        }
        $this->fillOrder($order);
        // 未结算前：不下发任何收款方式（对照示例站“结算之后才可以看是给谁付款”）
        if ((int) $order['settle_status'] !== 1) {
            $order['seller_pay'] = null;
            $this->success('success', $order);
        }
        // 卖家收款信息（个人对个人：抢了谁的就显示谁的收款方式；平台单取平台配置）
        // 统一返回结构：收款人 + 三种收款方式（银行卡 / 微信 / 支付宝）
        if ($order['type'] == 2 && $order['seller_id']) {
            $seller = Db::name('user')->where('id', $order['seller_id'])->field('nickname,mobile')->find();
            $pay = Db::name('user_pay')->where('user_id', $order['seller_id'])->find() ?: [];
            $order['seller_pay'] = [
                'payee_name'   => $seller['nickname'] ?? '',
                'card_name'    => $pay['card_name'] ?? '',
                'card_account' => $pay['card_account'] ?? '',
                'card_line'    => $pay['card_line'] ?? '',
                'card_branch'  => $pay['card_branch'] ?? '',
                'wx_account'   => $pay['wx_account'] ?? '',
                'wx_mobile'    => $pay['wx_mobile'] ?? '',
                'wx_image'     => !empty($pay['wx_image']) ? cdnurl($pay['wx_image'], true) : '',
                'zfb_account'  => $pay['zfb_account'] ?? '',
                'zfb_mobile'   => $pay['zfb_mobile'] ?? '',
                'zfb_image'    => !empty($pay['zfb_image']) ? cdnurl($pay['zfb_image'], true) : '',
            ];
        } else {
            $order['seller_pay'] = [
                'payee_name'   => $this->conf('platform_payee_name', '平台'),
                'card_name'    => $this->conf('platform_card_name'),
                'card_account' => $this->conf('platform_card_account'),
                'card_line'    => $this->conf('platform_card_line'),
                'card_branch'  => '',
                'wx_account'   => '',
                'wx_mobile'    => '',
                'zfb_account'  => '',
                'zfb_mobile'   => '',
                'zfb_image'    => $this->conf('platform_zfb_image') ? cdnurl($this->conf('platform_zfb_image'), true) : '',
                'wx_image'     => $this->conf('platform_wx_image') ? cdnurl($this->conf('platform_wx_image'), true) : '',
            ];
        }
        $this->success('success', $order);
    }

    /**
     * 本场结算（对照示例站“结算”页）
     * 按场次统计当前会员：本场出售应收(收款) / 本场购入应付(付款) / 净额(=补差额)
     * @param int $subarea_id 场次ID
     */
    public function getSettlement()
    {
        // subarea_id>0：单场次结算；subarea_id=0：聚合该会员全部场次（「我的→买入订单/委卖订单」入口）
        $subareaId = (int) $this->request->request('subarea_id', $this->request->request('id'));
        $uid = $this->auth->id;

        // 结算口径：读取「整轮批量结算」生成的差价净额付款单(fa_pay_order)。
        //   本场出售(我收) = 我是收款人(collect_user_id)；本场购入(我付) = 我是付款人(user_id)。
        //   金额为「差价净额」，与后台付款订单/示例站完全一致（不是一单一结算）。
        $poQuery = Db::name('pay_order');
        if ($subareaId > 0) {
            $poQuery->where('subarea_id', $subareaId);
        } else {
            // 聚合：只取与本会员相关的付款单（我收 或 我付）
            $poQuery->where(function ($q) use ($uid) {
                $q->where('collect_user_id', $uid)->whereOr('user_id', $uid);
            });
        }
        $pos = $poQuery->order('id asc')->select();

        $sell = [];      // 差价：我收（别人付给我）→ 可确认收款
        $buy = [];       // 差价：我付（我付给别人）→ 可上传付款凭证
        $sellTotal = 0;  // 应收合计
        $buyTotal = 0;   // 应付合计
        foreach ($pos as $p) {
            // 上架费(kind=2)：付款人=会员本人，收款人=平台。归入「本场购入(我付款)」展示，
            //   让会员上传平台上架费凭证（展示平台收款码），不计入差价净额（对照甲方：放本场购入而非本场出售）。
            if ((int) $p['kind'] === 2) {
                if ((int) $p['user_id'] === (int) $uid) {
                    $buy[] = $this->buildPayItem($p, $uid);
                }
                continue;
            }
            if ((int) $p['collect_user_id'] === (int) $uid) {
                $sellTotal += (float) $p['price'];
                $sell[] = $this->buildPayItem($p, $uid);
            } elseif ((int) $p['user_id'] === (int) $uid) {
                $buyTotal += (float) $p['price'];
                $buy[] = $this->buildPayItem($p, $uid);
            }
        }

        $sellTotal = round($sellTotal, 2);
        $buyTotal  = round($buyTotal, 2);
        // 净额 = 应收 - 应付：正=净收款，负=净付款
        $net = round($sellTotal - $buyTotal, 2);

        // 简化转售模式(biz_mode=1)：每笔付款单=一笔全额抢购单，
        //   结算页「相关商品」必须与对应「付款单」严格按 order_id 对齐，
        //   否则前端按下标配对会出现「两单支付金额正好反了」（甲方反馈的 bug）。
        // 「本场出售/本场购入」一律以「真实成交订单」为主列表：抢购/进货成功即显示（无需等后台结算）。
        //   付款单(差价/全额)由前端按 order_id 对齐到对应商品卡；结算后才出现付款单→才显示上传凭证按钮。
        //   这样既满足「抢购成功前端立即可见」，又保证 mall3 全额付款单与商品严格对齐不错位。
        $sellGoods = $this->sessionGoods($subareaId, $uid, true);
        $buyGoods  = $this->sessionGoods($subareaId, $uid, false);

        $this->success('success', [
            // 差价付款单（结算生成）
            'sell'       => $sell,
            'buy'        => $buy,
            // 本场真实成交的商品（对照甲方：本场出售/本场购入要把商品也显示出来）
            'sell_goods' => $sellGoods,
            'buy_goods'  => $buyGoods,
            'sell_total' => $sellTotal,
            'buy_total'  => $buyTotal,
            'net'        => $net,
            'net_type'   => $net >= 0 ? 'in' : 'out',
            'net_amount' => abs($net),
        ]);
    }

    /**
     * 收款人确认收到差价（对照示例站：收款方确认收款 → pay_status=2）
     * @param int $id 付款单ID(fa_pay_order)
     */
    public function confirmPayOrder()
    {
        $id = (int) $this->request->post('id');
        if (!$id) {
            $this->error('参数不正确');
        }
        $uid = $this->auth->id;
        $po = Db::name('pay_order')->where('id', $id)->find();
        if (!$po) {
            $this->error('付款单不存在');
        }
        if ((int) $po['collect_user_id'] !== (int) $uid) {
            $this->error('无权操作该付款单');
        }
        if ((int) $po['pay_status'] !== 1) {
            $this->error('该付款单当前不可确认收款');
        }
        Db::name('pay_order')->where('id', $id)->update([
            'pay_status' => 2,
            'pay_time'   => $po['pay_time'] ?: time(),
            'updatetime' => time(),
        ]);
        $this->success('已确认收款');
    }

    /**
     * 结算付款单：付款人上传付款凭证（差价/上架费）
     *   对照示例站：会员对自己「待支付」的付款单上传凭证后，状态变为「已支付待确认」，
     *   等待后台在「付款订单」中审核确认收款。
     * @param int    $id       付款单ID(fa_pay_order)
     * @param string $voucher  凭证图片路径
     * @param int    $pay_type 支付方式 0银行卡 1微信 2支付宝
     */
    public function payOrderVoucher()
    {
        $id = (int) $this->request->post('id');
        $voucher = trim((string) $this->request->post('voucher'));
        $payType = (int) $this->request->post('pay_type', 0);
        if (!$id || $voucher === '') {
            $this->error('参数不正确');
        }
        $uid = $this->auth->id;
        $po = Db::name('pay_order')->where('id', $id)->find();
        if (!$po) {
            $this->error('付款单不存在');
        }
        if ((int) $po['user_id'] !== (int) $uid) {
            $this->error('无权操作该付款单');
        }
        if ((int) $po['pay_status'] !== 0) {
            $this->error('该付款单当前不可上传凭证');
        }
        // 去掉可能的完整域名前缀，统一存相对路径
        $voucher = preg_replace('#^https?://[^/]+#', '', $voucher);
        Db::name('pay_order')->where('id', $id)->update([
            'image'      => $voucher,
            'pay_type'   => in_array($payType, [0, 1, 2]) ? $payType : 0,
            'pay_status' => 1,            // 已支付待确认
            'pay_time'   => time(),
            'updatetime' => time(),
        ]);
        $this->success('付款凭证已提交，等待对方/后台确认');
    }

    /**
     * 换位/转仓信息（可调整持有商品到下一场次）
     */
    public function getTranspositionInfo()
    {
        $uid = $this->auth->id;
        $holding = Db::name('warehouse')->where('user_id', $uid)->where('status', 1)->count();
        $selling = Db::name('warehouse')->where('user_id', $uid)->where('status', 2)->count();
        $subareas = Db::name('subarea')->where('warehouse_switch', 1)->field('id,name')->select();
        $this->success('success', [
            'holding_count' => $holding,
            'selling_count' => $selling,
            'subareas'      => $subareas,
            'increaseFee'   => $this->conf('increaseFee', 0),
        ]);
    }

    /**
     * 换位/转仓：把持有商品调整到指定场次（重新计算挂售价）
     * @param int $warehouse_id
     * @param int $subarea_id
     */
    public function transposition()
    {
        $wid = (int) $this->request->post('warehouse_id', $this->request->post('id'));
        $subareaId = (int) $this->request->post('subarea_id');
        if (!$wid || !$subareaId) {
            $this->error('参数不正确');
        }
        $wh = Db::name('warehouse')->where('id', $wid)->where('user_id', $this->auth->id)->find();
        if (!$wh) {
            $this->error('仓库记录不存在');
        }
        $increaseFee = (float) $this->conf('increaseFee', 0);
        $sellPrice = round((float) $wh['buy_price'] * (1 + $increaseFee / 100), 2);
        Db::name('warehouse')->where('id', $wid)->update([
            'subarea_id'   => $subareaId,
            'status'       => 2,
            'sell_price'   => $sellPrice,
            'selling_time' => time(),
            'updatetime'   => time(),
        ]);
        $this->success('换位成功', ['sell_price' => $sellPrice]);
    }
}

<?php

namespace app\common\library;

use think\Db;

/**
 * 团队 / 会员等级 业务服务
 *
 * 等级规则（甲方需求，阈值后台可配置）：
 *   1 = 经销商（初始，所有人默认）
 *   2 = 经理：团队累计人数达到 manager_promote_count（默认6，即「6个经销商」）
 *   3 = 股东：团队中「经理及以上」数量达到 shareholder_manager_count（默认4，即「4个经理」）
 *   4 = 老板：团队中「股东及以上」数量达到 boss_shareholder_count（默认2，即「2个股东」）
 *
 * 团队关系：fa_user.team_path 存储祖先链（逗号分隔，顶级在前），
 *   某会员的全部下级 = team_path 中包含其 id 的会员（FIND_IN_SET）。
 */
class TeamService
{
    /** 等级名称映射 */
    public static function levelName($level)
    {
        $map = [
            1 => self::conf('level1_name', '经销商'),
            2 => self::conf('level2_name', '经理'),
            3 => self::conf('level3_name', '股东'),
            4 => self::conf('level4_name', '老板'),
        ];
        return isset($map[$level]) ? $map[$level] : '经销商';
    }

    /** 读取 mall 配置 */
    protected static function conf($name, $default = '')
    {
        $v = Db::name('config')->where('name', $name)->value('value');
        return ($v === null || $v === '') ? $default : $v;
    }

    /**
     * 获取某会员的全部下级会员ID
     *
     * 说明：以「实时 pid 关系」逐层向下遍历，而不是依赖 team_path。
     *   原因：后台手动修改上级、批量导入会员时 team_path 未必写入，
     *   若用 FIND_IN_SET(uid, team_path) 会导致「有粉丝数量却查不到粉丝列表」。
     *   pid 是登录/注册/后台指派都会正确维护的字段，因此最可靠。
     * @param int $uid
     * @return array 全部下级ID（不含本人）
     */
    public static function getDescendantIds($uid)
    {
        $uid = (int) $uid;
        if ($uid <= 0) {
            return [];
        }
        $all      = [];        // 已收集的下级ID（去重）
        $frontier = [$uid];    // 当前层
        $guard    = 0;         // 防止脏数据成环导致死循环
        while (!empty($frontier) && $guard < 100) {
            $children = Db::name('user')->where('pid', 'in', $frontier)->column('id');
            $children = array_map('intval', $children);
            // 排除本人与已收集，避免环
            $children = array_values(array_diff($children, array_keys($all), [$uid]));
            if (empty($children)) {
                break;
            }
            foreach ($children as $c) {
                $all[$c] = true;
            }
            $frontier = $children;
            $guard++;
        }
        return array_keys($all);
    }

    /**
     * 团队累计人数（全部下级）
     */
    public static function teamTotal($uid)
    {
        return count(self::getDescendantIds($uid));
    }

    /**
     * 团队中"经理及以上"的数量（level>=2）
     */
    public static function managerCount($uid)
    {
        $ids = self::getDescendantIds($uid);
        return $ids ? Db::name('user')->where('id', 'in', $ids)->where('level', '>=', 2)->count() : 0;
    }

    /**
     * 团队中"股东及以上"的数量（level>=3）
     */
    public static function shareholderCount($uid)
    {
        $ids = self::getDescendantIds($uid);
        return $ids ? Db::name('user')->where('id', 'in', $ids)->where('level', '>=', 3)->count() : 0;
    }

    /**
     * 直推人数（仅下一级）
     */
    public static function directCount($uid)
    {
        return Db::name('user')->where('pid', $uid)->count();
    }

    /**
     * 按规则重新计算并更新单个会员的等级
     * @param int $uid
     * @return int 新等级
     */
    public static function recalc($uid)
    {
        // 阈值后台可配置：6个经销商→经理；4个经理→股东；2个股东→老板
        $managerPromote     = (int) self::conf('manager_promote_count', 6);     // 团队累计人数（≈6个经销商）
        $shareholderManager = (int) self::conf('shareholder_manager_count', 4); // 团队中经理数量
        $bossShareholder    = (int) self::conf('boss_shareholder_count', 2);    // 团队中股东数量

        $total        = self::teamTotal($uid);
        $managers     = self::managerCount($uid);
        $shareholders = self::shareholderCount($uid);

        $level = 1; // 经销商（初始）
        if ($total >= $managerPromote) {
            $level = 2; // 经理
        }
        if ($level >= 2 && $managers >= $shareholderManager) {
            $level = 3; // 股东
        }
        if ($level >= 3 && $shareholders >= $bossShareholder) {
            $level = 4; // 老板
        }

        Db::name('user')->where('id', $uid)->update([
            'level'      => $level,
            'is_team'    => $level >= 2 ? 1 : 0,
            'updatetime' => time(),
        ]);
        return $level;
    }

    /**
     * 重新计算某会员及其全部上级的等级
     * 用于新会员注册 / 团队结构变化后，自下而上刷新等级。
     * @param int $uid 触发变化的会员
     */
    public static function recalcChain($uid)
    {
        $user = Db::name('user')->where('id', $uid)->find();
        if (!$user) {
            return;
        }
        // 先算自己，再算所有祖先（多轮，确保经理数量变化能向上传导）
        $ids = [$uid];
        if (!empty($user['team_path'])) {
            foreach (explode(',', $user['team_path']) as $aid) {
                if ($aid !== '' && (int) $aid > 0) {
                    $ids[] = (int) $aid;
                }
            }
        }
        // 由下而上多轮计算：经理→股东→老板逐级向上传导（4级需3轮收敛）
        for ($round = 0; $round < 3; $round++) {
            // 距离自己近的先算（数组末尾是顶级，反转后顶级最后）
            foreach (array_reverse($ids) as $id) {
                self::recalc($id);
            }
        }
    }

    /**
     * 团队分组统计：返回各等级人数（用于会员中心/团队页"分组"显示）
     * @param int $uid
     * @return array
     */
    public static function groupStat($uid)
    {
        $ids = self::getDescendantIds($uid);
        if (!$ids) {
            return [
                'total'           => 0,
                'distributor'     => 0, // 经销商
                'manager'         => 0, // 经理
                'shareholder'     => 0, // 股东
                'boss'            => 0, // 老板
                'direct'          => 0, // 直推
            ];
        }
        $rows = Db::name('user')->where('id', 'in', $ids)->column('level');
        $distributor = $manager = $shareholder = $boss = 0;
        foreach ($rows as $lv) {
            if ($lv >= 4) {
                $boss++;
            } elseif ($lv == 3) {
                $shareholder++;
            } elseif ($lv == 2) {
                $manager++;
            } else {
                $distributor++;
            }
        }
        return [
            'total'       => count($ids),
            'distributor' => $distributor,
            'manager'     => $manager,
            'shareholder' => $shareholder,
            'boss'        => $boss,
            'direct'      => self::directCount($uid),
        ];
    }
}

define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'subarea.goods/index' + location.search,
                    add_url: 'subarea.goods/add',
                    edit_url: 'subarea.goods/edit',
                    del_url: 'subarea.goods/del',
                    multi_url: 'subarea.goods/multi',
                    import_url: 'subarea.goods/import',
                    table: 'subarea_goods',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                sortOrder: 'desc',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'mobile', title: '手机号', operate: false},
                        {field: 'subarea_name', title: '场次名称', operate: false},
                        {field: 'goods_name', title: '商品名称', operate: false},
                        {field: 'price', title: '商品价格', operate:'BETWEEN'},
                        {field: 'cover_image', title: '封面图', operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'carousel_image', title: '轮播图', operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'status', title: '状态', searchList: {"0":'停用',"1":'启用'}, formatter: Table.api.formatter.status},
                        {field: 'createtime', title: '创建时间', operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate,
                            buttons: [
                                {name: 'assign', text: '指派用户', title: '指派用户', classname: 'btn btn-xs btn-success btn-assignuser', icon: 'fa fa-user'}
                            ],
                            formatter: Table.api.formatter.operate}
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            // 指派用户：自定义可搜索下拉（服务端 userList 全部会员 + 手机号/昵称/用户名模糊搜索 + 点击选中）
            var assignSearchTimer = null;
            function assignRenderList(list) {
                var $box = $('#assign-user-list');
                if (!list || !list.length) { $box.html('<div style="padding:12px;color:#999;text-align:center;">无匹配会员</div>'); return; }
                var h = '';
                for (var i = 0; i < list.length; i++) {
                    h += '<a href="javascript:;" class="au-item" data-id="' + list[i].id + '" data-name="' + $('<div>').text(list[i].name).html() + '" '
                        + 'style="display:block;padding:8px 12px;border-bottom:1px solid #f5f5f5;color:#333;text-decoration:none;">'
                        + $('<div>').text(list[i].name).html() + '</a>';
                }
                $box.html(h);
            }
            function assignFetch(kw) {
                $.get('subarea.goods/userList', { q_word: kw || '' }, function (ret) {
                    assignRenderList((ret && ret.list) || []);
                }, 'json');
            }
            $(document).on('click', '.btn-assignuser', function () {
                var data = table.bootstrapTable('getData');
                var index = $(this).parents('tr').data('index');
                var row = data[index];
                if (!row) { Toastr.error('未获取到商品'); return; }
                var html = '<div style="padding:16px 20px;">'
                    + '<div style="margin-bottom:10px;color:#666;">商品：' + (row.goods_id ? ('#' + row.goods_id) : '') + '　价格：¥' + (row.price || 0) + '</div>'
                    + '<label>指派所属用户（输入手机号/昵称模糊搜索）：</label>'
                    + '<input id="assign-user-search" class="form-control" autocomplete="off" placeholder="输入手机号或昵称搜索，点击下方会员选择" style="margin-top:8px;">'
                    + '<input type="hidden" id="assign-user-id" value="">'
                    + '<div id="assign-user-picked" style="margin-top:6px;min-height:20px;color:#14b8a6;"></div>'
                    + '<div id="assign-user-list" style="margin-top:6px;max-height:240px;overflow:auto;border:1px solid #eee;border-radius:4px;"></div>'
                    + '</div>';
                Layer.open({
                    type: 1, title: '指派所属用户', area: ['460px', '460px'], content: html,
                    success: function () {
                        assignFetch('');
                        $('#assign-user-search').off('keyup.assign').on('keyup.assign', function () {
                            var kw = $.trim($(this).val());
                            clearTimeout(assignSearchTimer);
                            assignSearchTimer = setTimeout(function () { assignFetch(kw); }, 250);
                        });
                    },
                    btn: ['提交', '取消'],
                    yes: function (idx) {
                        var uid = $('#assign-user-id').val();
                        if (!uid) { Toastr.error('请选择用户'); return; }
                        // 防重：连点「提交」只发一次请求，避免生成多条抢购订单
                        if (window.__assigning) { return; }
                        window.__assigning = true;
                        $.ajax({
                            url: 'subarea.goods/assignuser', type: 'post', dataType: 'json',
                            data: { ids: row.id, user_id: uid },
                            success: function (r) {
                                if (r.code === 1) { Toastr.success(r.msg); Layer.close(idx); table.bootstrapTable('refresh'); }
                                else { Toastr.error(r.msg || '指派失败'); }
                            },
                            error: function () { Toastr.error('请求失败'); },
                            complete: function () { window.__assigning = false; }
                        });
                    }
                });
            });
            // 选择某个会员
            $(document).on('click', '.au-item', function () {
                var id = $(this).data('id');
                var name = $(this).data('name');
                $('#assign-user-id').val(id);
                $('#assign-user-picked').text('已选择：' + name);
                $('.au-item').css('background', '');
                $(this).css('background', '#e2f6f3');
            });
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});

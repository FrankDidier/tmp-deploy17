define(['jquery', 'bootstrap', 'backend', 'table', 'form'], function ($, undefined, Backend, Table, Form) {

    var Controller = {
        index: function () {
            // 初始化表格参数配置
            Table.api.init({
                extend: {
                    index_url: 'order/index' + location.search,
                    add_url: 'order/add',
                    edit_url: 'order/edit',
                    del_url: 'order/del',
                    multi_url: 'order/multi',
                    import_url: 'order/import',
                    table: 'order',
                }
            });

            var table = $("#table");

            // 初始化表格
            table.bootstrapTable({
                url: $.fn.bootstrapTable.defaults.extend.index_url,
                pk: 'id',
                sortName: 'id',
                fixedColumns: true,
                fixedRightNumber: 1,
                columns: [
                    [
                        {checkbox: true},
                        {field: 'id', title: __('Id')},
                        {field: 'order_no', title: __('Order_no'), operate: 'LIKE'},
                        {field: 'subarea.name', title: __('Subarea_id'), operate: false, formatter: Table.api.formatter.label},
                        {field: 'goods.image', title: __('Goods_id'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'goods.name', title: '商品名称', operate: 'LIKE'},
                        {field: 'type', title: __('Type'), searchList: {"1":__('Type 1'),"2":__('Type 2')}, formatter: Table.api.formatter.normal},
                        {field: 'seller.nickname', title: '卖方', operate: 'LIKE', formatter: Table.api.formatter.search},
                        {field: 'seller.mobile', title: '卖方手机号', operate: 'LIKE'},
                        {field: 'buyer.nickname', title: '买方', operate: 'LIKE', formatter: Table.api.formatter.search},
                        {field: 'buyer.mobile', title: '买方手机号', operate: 'LIKE'},
                        {field: 'buy_price', title: '买价', operate: false, formatter: function (value, row) { return value == null ? (row.amount == null ? '-' : row.amount) : value; }},
                        {field: 'sell_price', title: '卖价', operate: false, formatter: function (value, row) { return value == null ? row.amount : value; }},
                        {field: 'profit', title: '收益', operate: false, formatter: function (value) { if (value == null) return '-'; var v = parseFloat(value); return '<span style="color:' + (v >= 0 ? '#18bc9c' : '#e74c3c') + '">' + value + '</span>'; }},
                        {field: 'pay_status', title: '状态', searchList: {"0":__('Pay_status 0'),"1":__('Pay_status 1'),"2":__('Pay_status 2'),"3":__('Pay_status 3')}, formatter: function (value, row) { return row.status_text || ''; }},
                        {field: 'settle_status', title: '结算状态', searchList: {"0":"未结算","1":"已结算待付款"}, formatter: function (value) { return value == 1 ? '<span class="label label-success">已结算待付款</span>' : '<span class="label label-default">未结算</span>'; }},
                        {field: 'audit_status', title: '审核状态', operate: false, formatter: function (value, row) { return row.audit_text || ''; }},
                        {field: 'pay_type', title: __('Pay_type'), searchList: {"1":__('Pay_type 1'),"2":__('Pay_type 2'),"3":__('Pay_type 3')}, formatter: Table.api.formatter.normal},
                        {field: 'pay_voucher', title: __('Pay_voucher'), operate: false, events: Table.api.events.image, formatter: Table.api.formatter.image},
                        {field: 'pay_time', title: __('Pay_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, visible:false, formatter: Table.api.formatter.datetime},
                        {field: 'confirm_time', title: __('Confirm_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, visible:false, formatter: Table.api.formatter.datetime},
                        {field: 'expire_time', title: __('Expire_time'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, visible:false, formatter: Table.api.formatter.datetime},
                        {field: 'remark', title: __('Remark'), operate: 'LIKE', visible:false, table: table, class: 'autocontent', formatter: Table.api.formatter.content},
                        {field: 'createtime', title: __('Createtime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, formatter: Table.api.formatter.datetime},
                        {field: 'updatetime', title: __('Updatetime'), operate:'RANGE', addclass:'datetimerange', autocomplete:false, visible:false, formatter: Table.api.formatter.datetime},
                        {
                            field: 'operate', title: __('Operate'), table: table, events: Table.api.events.operate,
                            buttons: [
                                // 「结算」已统一为顶部工具栏批量结算（对照甲方：删除逐行结算按钮）
                                {
                                    name: 'confirm', text: '确认收款', classname: 'btn btn-xs btn-primary btn-ajax',
                                    icon: 'fa fa-check', url: 'order/confirm', confirm: '确认买家已付款并结算该订单？（商品入库 + 卖家收益 + 团队分润）',
                                    success: function () { table.bootstrapTable('refresh'); },
                                    visible: function (row) { return row.pay_status != 2 && row.pay_status != 3; }
                                },
                                {
                                    name: 'assign', text: '指派', classname: 'btn btn-xs btn-info btn-dialog',
                                    icon: 'fa fa-user-plus', url: 'order/hair',
                                    // 指派仅在「未结算、未付款、且未上架进抢购池」时可用；
                                    // 批量上架后(商品已进抢购板 listed=1)/结算后/已付款/已确认不再显示（对照甲方反馈）
                                    visible: function (row) { return !row.listed && row.settle_status != 1 && row.pay_status != 1 && row.pay_status != 2 && row.pay_status != 3; }
                                },
                                {
                                    name: 'split', text: '拆分', classname: 'btn btn-xs btn-success btn-ajax',
                                    icon: 'fa fa-clone', url: 'order/split',
                                    confirm: '确认把该订单平均拆分成两单吗？（金额对半分，复制商品，删除原单，生成两条委卖订单）',
                                    success: function () { table.bootstrapTable('refresh'); }
                                },
                                {
                                    name: 'offline', text: '下架', classname: 'btn btn-xs btn-warning btn-ajax',
                                    icon: 'fa fa-arrow-down', url: 'order/offline', confirm: '确认下架该订单商品？',
                                    success: function () { table.bootstrapTable('refresh'); }
                                },
                                {
                                    // 取消订单：取消买方本单，商品回抢购池，前台可重新抢购（已确认收款的不显示）
                                    name: 'cancel', text: '取消订单', classname: 'btn btn-xs btn-danger btn-ajax',
                                    icon: 'fa fa-times', url: 'order/cancel',
                                    confirm: '确认取消买方本单？取消后该商品回到抢购池，前台可重新抢购。',
                                    success: function () { table.bootstrapTable('refresh'); },
                                    visible: function (row) { return row.buyer_id > 0 && row.pay_status != 2; }
                                }
                            ],
                            formatter: Table.api.formatter.operate
                        }
                    ]
                ]
            });

            // 为表格绑定事件
            Table.api.bindevent(table);

            // 工具栏批量操作：批量上架 / 结算 / 开启转售
            var batchOp = function (url, confirmText) {
                var ids = Table.api.selectedids(table);
                if (!ids.length) {
                    Toastr.error('请先勾选订单');
                    return;
                }
                Layer.confirm(confirmText, function (idx) {
                    Layer.close(idx);
                    $.ajax({
                        url: url, type: 'post', dataType: 'json', data: {ids: ids.join(',')},
                        success: function (ret) {
                            if (ret.code === 1) { Toastr.success(ret.msg); table.bootstrapTable('refresh'); }
                            else { Toastr.error(ret.msg || '操作失败'); }
                        },
                        error: function () { Toastr.error('请求失败'); }
                    });
                });
            };
            $(document).on('click', '.btn-online', function () { batchOp('order/online', '确认将所选订单商品批量上架到寄售池？'); });
            $(document).on('click', '.btn-settle', function () { batchOp('order/settle', '确认对所选订单进行后台结算？结算后买家方可上传付款凭证。'); });
            $(document).on('click', '.btn-confirmall', function () { batchOp('order/confirm', '确认对所选订单确认收款并结算（入库 + 卖家收益 + 团队分润）？'); });
            $(document).on('click', '.btn-resale', function () { batchOp('order/resale', '确认对所选订单按溢价开启转售？'); });

            // 一键清空交易数据（清空后前端抢购板/仓库/资金流水与首页统计同步归零）
            $(document).on('click', '.btn-cleardata', function () {
                Layer.confirm('确认清空【全部】交易数据吗？将删除：抢购订单 / 仓库持仓 / 抢购板商品 / 付款订单 / 资金流水 / 团队收益，并把所有会员余额重置为0。此操作不可恢复！', {icon: 0, title: '危险操作'}, function (idx) {
                    Layer.close(idx);
                    $.ajax({
                        url: 'order/clearData', type: 'post', dataType: 'json',
                        success: function (ret) {
                            if (ret.code === 1) { Toastr.success(ret.msg); table.bootstrapTable('refresh'); }
                            else { Toastr.error(ret.msg || '操作失败'); }
                        },
                        error: function () { Toastr.error('请求失败'); }
                    });
                });
            });

            // 买单/卖单 切换：按 type 过滤（type=1 抢购/买单，type=2 寄售/卖单）
            $(document).on('click', '.nav-tabs[data-field] a', function (e) {
                e.preventDefault();
                var $li = $(this).closest('li');
                $li.addClass('active').siblings().removeClass('active');
                var field = $(this).closest('ul').data('field');
                var value = $(this).attr('data-value');
                var filter = {}, op = {};
                if (value !== '' && value != null) { filter[field] = value; op[field] = '='; }
                table.bootstrapTable('refresh', { query: { filter: JSON.stringify(filter), op: JSON.stringify(op) } });
            });
        },
        add: function () {
            Controller.api.bindevent();
        },
        edit: function () {
            Controller.api.bindevent();
        },
        hair: function () {
            Controller.api.bindevent();
        },
        split: function () {
            Controller.api.bindevent();
            // 自定义拆分动态行：追加时重新绑定下拉/校验组件
            $(document).on("fa.event.appendfieldlist", '#chaifen .btn-append', function (e, obj) {
                Form.events.selectpage(obj);
                Form.api.bindevent(obj);
            });
        },
        api: {
            bindevent: function () {
                Form.api.bindevent($("form[role=form]"));
            }
        }
    };
    return Controller;
});

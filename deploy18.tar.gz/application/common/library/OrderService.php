<?php

namespace app\common\library;

use think\Db;

/**
 * 订单结算服务（前台“确认收款”与后台“确认收款/结算”共用同一套逻辑）
 *
 * 经济模型（后台 mall 配置可调）：
 *   increaseFee  涨幅%   —— 商品转入买家仓库后的默认挂售涨幅
 *   listingFee   服务费% —— 平台手续费（按原买入价计）
 *   team_profit_rate 分佣% —— 从手续费中分给上级团队长
 *
 * 商城业务：个人对个人抢单，商城仅做结算记账，资金由买卖双方互相支付。
 */
class OrderService
{
    /** 读取 mall 配置 */
    protected static function conf($name, $default = '')
    {
        $v = Db::name('config')->where('name', $name)->value('value');
        return ($v === null || $v === '') ? $default : $v;
    }

    /**
     * 结算一笔订单：商品转入买家仓库 + 卖家收益 + 平台服务费 + 团队分润
     * @param array $order 订单数组
     */
    public static function settle($order)
    {
        $increaseFee = (float) self::conf('increaseFee', 0);
        $buyPrice = (float) $order['amount'];
        $sellPrice = round($buyPrice * (1 + $increaseFee / 100), 2);

        // 会员单：原仓库记录标记已售
        if ($order['type'] == 2 && $order['warehouse_id']) {
            Db::name('warehouse')->where('id', $order['warehouse_id'])->update([
                'status'     => 3,
                'sold_time'  => time(),
                'updatetime' => time(),
            ]);
        }
        // 商品转入买家仓库（已入库 持有中）
        Db::name('warehouse')->insert([
            'user_id'    => $order['buyer_id'],
            'goods_id'   => $order['goods_id'],
            'subarea_id' => $order['subarea_id'],
            'order_id'   => $order['id'],
            'buy_price'  => $buyPrice,
            'sell_price' => $sellPrice,
            'status'     => 1,
            'createtime' => time(),
            'updatetime' => time(),
        ]);

        // 商品列表(商品管理)归属跟随最新买家（对照甲方：抢购完成→只更新归属为最新抢购人）。
        //   同款(同 goods_id)可能有多条挂牌(归属同一会员，价格不同)，必须「只更新本条」，否则串号。
        //   精确定位：归属=卖家 + 价格=本单关联仓库的买入价(=该挂牌指派/挂售价)，命中取一条按ID更新。
        if ($order['goods_id'] && $order['subarea_id']) {
            $ow = $order['warehouse_id']
                ? Db::name('warehouse')->where('id', $order['warehouse_id'])->find()
                : null;
            $matchPrice = $ow ? (float) $ow['buy_price'] : (float) $order['amount'];
            $sgWhere = [
                'goods_id'   => $order['goods_id'],
                'subarea_id' => $order['subarea_id'],
                'user_id'    => (int) $order['seller_id'],
            ];
            $sg = Db::name('subarea_goods')->where($sgWhere)->where('price', $matchPrice)->order('id desc')->find();
            if (!$sg) {
                $sg = Db::name('subarea_goods')->where($sgWhere)->order('id desc')->find(); // 兜底
            }
            if ($sg) {
                Db::name('subarea_goods')->where('id', $sg['id'])
                    ->update(['user_id' => (int) $order['buyer_id'], 'updatetime' => time()]);
            }
        }

        // 卖家收益 + 平台服务费 + 团队分润（仅会员对会员单）
        if ($order['type'] == 2 && $order['seller_id']) {
            $listingFee = (float) self::conf('listingFee', 0);
            $seller = Db::name('user')->where('id', $order['seller_id'])->find();
            // 收益基数 = 本单「成交价(买家实付 = order.amount)」，不是卖家历史买入成本。
            //   场景：A 以 1000 抢入并按 1030 挂售，B 以 1030 抢入 → 卖家 A 的收益按 1030 算。
            //   甲方公式：收益 = 成交价 ×（交易利益比% − 手续费%），如 1030 × 1.3% = 13.39。
            $cost = $buyPrice;
            $procedures = round($cost * $listingFee / 100, 2);    // 平台服务费(手续费 1.7%)
            $income = round($cost * ($increaseFee - $listingFee) / 100, 2); // 卖家净收益(1.3%)
            if ($income != 0 && $seller) {
                // 卖家净收益只累加到「我的利润」(profit)，不再计入「优惠券余额」(money)。
                //   （money 现为纯优惠券钱包：仅「抢购返券」自动累加 + 后台手动增减 + 兑换/提现扣减，
                //     故不能再把卖家成交收益混进 money，否则优惠券会与利润一样被撑大——甲方反馈的问题根源）
                Db::name('user')->where('id', $seller['id'])->setInc('profit', $income);
                Db::name('profit_log')->insert([
                    'user_id' => $seller['id'], 'from_user_id' => $order['buyer_id'], 'order_id' => $order['id'],
                    'money' => $income, 'type' => 1, 'memo' => '溢价净收益', 'createtime' => time(),
                ]);
            }
            if ($procedures > 0) {
                Db::name('profit_log')->insert([
                    'user_id' => 0, 'from_user_id' => $seller ? $seller['id'] : 0, 'order_id' => $order['id'],
                    'money' => $procedures, 'type' => 3, 'memo' => '平台服务费', 'createtime' => time(),
                ]);
            }
            // 团队分润功能已按甲方要求下线（不再生成 type=2「团队分润」收益记录）。
            //   如需恢复，取消下一行注释即可。
            // if ($seller) {
            //     self::teamProfit($seller, $procedures, $order);
            // }
        }

        // 抢购返优惠券：买家抢购成交(确认收款)时，按「优惠券比例(coupon_rate%)」给买家自动累加优惠券余额(money)。
        //   —— 对应甲方选项C：系统自动把「抢购额×比例」累加进优惠券余额，后台仍可手动增减；前端显示该余额。
        //   仅统计商品交易单(type=1/2)，排除上架费单(pay_kind=2)。settle 每单只执行一次(确认幂等)，不会重复返券。
        $rate = (float) self::conf('coupon_rate', 0.5);
        $isGrab = in_array((int) $order['type'], [1, 2], true) && (int) ($order['pay_kind'] ?? 0) !== 2;
        if ($rate > 0 && $isGrab && !empty($order['buyer_id'])) {
            $coupon = round($buyPrice * $rate / 100, 2);
            if ($coupon > 0) {
                $bb = (float) Db::name('user')->where('id', $order['buyer_id'])->value('money');
                $aa = round($bb + $coupon, 2);
                Db::name('user')->where('id', $order['buyer_id'])->update(['money' => $aa, 'updatetime' => time()]);
                Db::name('user_money_log')->insert([
                    'user_id' => $order['buyer_id'], 'money' => $coupon, 'before' => $bb, 'after' => $aa,
                    'memo' => '抢购返优惠券(' . $rate . '%)', 'createtime' => time(),
                ]);
            }
        }
    }

    /**
     * 团队分润：卖家成交后，其最近的一个团队长上级按配置比例获得分润
     */
    protected static function teamProfit($seller, $profit, $order)
    {
        if ($profit <= 0 || empty($seller['team_path'])) {
            return;
        }
        $rate = (float) self::conf('team_profit_rate', 0);
        if ($rate <= 0) {
            return;
        }
        $ancestors = array_reverse(array_filter(explode(',', $seller['team_path'])));
        foreach ($ancestors as $aid) {
            $leader = Db::name('user')->where('id', (int) $aid)->find();
            if ($leader && $leader['is_team']) {
                $bonus = round($profit * $rate / 100, 2);
                if ($bonus > 0) {
                    $before = (float) $leader['money'];
                    $after = round($before + $bonus, 2);
                    Db::name('user')->where('id', $leader['id'])->update(['money' => $after]);
                    // 我的利润余额同步累加
                    Db::name('user')->where('id', $leader['id'])->setInc('profit', $bonus);
                    Db::name('user_money_log')->insert([
                        'user_id' => $leader['id'], 'money' => $bonus, 'before' => $before,
                        'after' => $after, 'memo' => '团队分润', 'createtime' => time(),
                    ]);
                    Db::name('profit_log')->insert([
                        'user_id' => $leader['id'], 'from_user_id' => $seller['id'], 'order_id' => $order['id'],
                        'money' => $bonus, 'type' => 2, 'memo' => '团队分润', 'createtime' => time(),
                    ]);
                }
                break;
            }
        }
    }
}

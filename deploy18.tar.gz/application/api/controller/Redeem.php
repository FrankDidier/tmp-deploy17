<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\CouponService;
use think\Db;
use think\Exception;

/**
 * 兑换区：用「优惠券/佣金」（fa_user.money）抵扣兑换后台上传的兑换商品
 */
class Redeem extends Api
{
    protected $noNeedLogin = ['getList', 'getInfo'];
    protected $noNeedRight = '*';

    protected function getPage()
    {
        $page = (int) $this->request->request('page', 1);
        $pageSize = (int) $this->request->request('page_size', 15);
        return [max(1, $page), max(1, $pageSize)];
    }

    /** 兑换商品列表 + 我的可用优惠券余额 */
    public function getList()
    {
        $balance = 0;
        if ($this->auth->isLogin()) {
            // 优惠券余额 = fa_user.money（后台可手改，前端一致）
            $balance = (float) Db::name('user')->where('id', $this->auth->id)->value('money');
        }
        $rows = Db::name('redeem_goods')->where('status', 1)
            ->order('weigh desc,id desc')->select();
        $list = [];
        foreach ($rows as $r) {
            $list[] = [
                'id'    => (int) $r['id'],
                'name'  => $r['name'],
                'image' => $r['image'] ? cdnurl($r['image'], true) : '',
                'cost'  => round((float) $r['cost'], 2),
                'stock' => (int) $r['stock'],
            ];
        }
        $this->success('success', ['balance' => $balance, 'list' => $list]);
    }

    /** 兑换商品详情（含富文本 content） */
    public function getInfo()
    {
        $id = (int) $this->request->request('id');
        $r = Db::name('redeem_goods')->where('id', $id)->find();
        if (!$r) {
            $this->error('兑换商品不存在');
        }
        $balance = $this->auth->isLogin() ? (float) Db::name('user')->where('id', $this->auth->id)->value('money') : 0;
        $this->success('success', [
            'id'      => (int) $r['id'],
            'name'    => $r['name'],
            'image'   => $r['image'] ? cdnurl($r['image'], true) : '',
            'content' => isset($r['content']) ? (string) $r['content'] : '',
            'cost'    => round((float) $r['cost'], 2),
            'stock'   => (int) $r['stock'],
            'status'  => (int) $r['status'],
            'balance' => $balance,
        ]);
    }

    /** 兑换（扣减优惠券余额、减库存、写兑换记录，需填写/选择收货地址） */
    public function exchange()
    {
        $id = (int) $this->request->post('id');
        if ($id <= 0) {
            $this->error('参数错误');
        }
        // 收货地址：优先取已保存地址(address_id)，否则取直接传入的姓名/电话/地址
        $addressId = (int) $this->request->post('address_id', 0);
        $recvName = trim((string) $this->request->post('recv_name', ''));
        $recvMobile = trim((string) $this->request->post('recv_mobile', ''));
        $recvAddress = trim((string) $this->request->post('recv_address', ''));
        if ($addressId > 0) {
            $addr = Db::name('address')->where('id', $addressId)->where('user_id', $this->auth->id)->find();
            if ($addr) {
                $recvName = $addr['name'];
                $recvMobile = $addr['mobile'];
                $recvAddress = trim(($addr['address'] ?? '') . ' ' . ($addr['detail'] ?? ''));
            }
        }
        if ($recvName === '' || $recvMobile === '' || $recvAddress === '') {
            $this->error('请先填写或选择收货地址');
        }
        Db::startTrans();
        try {
            $goods = Db::name('redeem_goods')->where('id', $id)->lock(true)->find();
            if (!$goods || (int) $goods['status'] !== 1) {
                throw new Exception('兑换商品不存在或已下架');
            }
            if ((int) $goods['stock'] <= 0) {
                throw new Exception('库存不足');
            }
            $uid = $this->auth->id;
            $cost = round((float) $goods['cost'], 2);
            // 优惠券余额 = fa_user.money（后台可手改，前端一致）；兑换即从该余额扣减
            $userRow = Db::name('user')->where('id', $uid)->lock(true)->find();
            $before = (float) ($userRow['money'] ?? 0);
            if ($before < $cost) {
                throw new Exception('优惠券余额不足');
            }
            Db::name('user')->where('id', $uid)->setDec('money', $cost);
            Db::name('redeem_goods')->where('id', $id)->setDec('stock');
            Db::name('redeem_log')->insert([
                'user_id'      => $uid,
                'goods_id'     => $id,
                'goods_name'   => $goods['name'],
                'image'        => $goods['image'],
                'cost'         => $cost,
                'recv_name'    => $recvName,
                'recv_mobile'  => $recvMobile,
                'recv_address' => $recvAddress,
                'status'       => 1,
                'createtime'   => time(),
            ]);
            Db::commit();
            $this->success('兑换成功');
        } catch (Exception $e) {
            Db::rollback();
            $this->error($e->getMessage());
        }
    }

    /** 我的兑换记录 */
    public function getLog()
    {
        list($page, $pageSize) = $this->getPage();
        $res = Db::name('redeem_log')->where('user_id', $this->auth->id)
            ->order('id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $list = $res->items();
        foreach ($list as &$v) {
            $v['image'] = $v['image'] ? cdnurl($v['image'], true) : '';
            $v['cost'] = round((float) $v['cost'], 2);
            $v['status_text'] = [0 => '处理中', 1 => '兑换成功', 2 => '已取消'][$v['status']] ?? '';
            $v['recv_name'] = $v['recv_name'] ?? '';
            $v['recv_mobile'] = $v['recv_mobile'] ?? '';
            $v['recv_address'] = $v['recv_address'] ?? '';
            $v['createtime_text'] = $v['createtime'] ? date('Y-m-d H:i', $v['createtime']) : '';
        }
        unset($v);
        $this->success('success', ['list' => $list, 'total' => $res->total(), 'last_page' => $res->lastPage()]);
    }
}

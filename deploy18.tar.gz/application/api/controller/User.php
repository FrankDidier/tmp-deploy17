<?php

namespace app\api\controller;

use app\common\controller\Api;
use app\common\library\Sms;
use fast\Random;
use think\Db;
use think\Validate;

/**
 * 会员接口（登录/注册/会员中心/资金/签约）
 */
class User extends Api
{
    protected $noNeedLogin = ['login', 'mobilelogin', 'register', 'resetpwd'];
    protected $noNeedRight = '*';

    /**
     * 校验短信验证码
     * 开发期支持万能验证码（mall 配置 sms_master_code，默认 123456），便于联调；
     * 正式环境可清空该配置，仅走真实短信。
     */
    protected function checkSms($mobile, $code, $event)
    {
        $master = Db::name('config')->where('name', 'sms_master_code')->value('value');
        if ($master !== null && $master !== '' && $code == $master) {
            return true;
        }
        return Sms::check($mobile, $code, $event);
    }

    /**
     * 分页参数（缺失报错，保持与示例站一致）
     */
    protected function getPage()
    {
        $page = $this->request->request('page');
        $pageSize = $this->request->request('page_size');
        if ($page === null || $page === '') {
            $this->error('page不能为空');
        }
        if ($pageSize === null || $pageSize === '') {
            $this->error('page_size不能为空');
        }
        return [max(1, (int) $page), max(1, (int) $pageSize)];
    }

    /**
     * 会员登录（账号 account + 密码 password）
     * @ApiMethod (POST)
     */
    public function login()
    {
        $account = $this->request->post('account');
        $password = $this->request->post('password');
        if (!$account || !$password) {
            $this->error('参数不正确');
        }
        $ret = $this->auth->login($account, $password);
        if ($ret) {
            $this->success('登录成功', ['userinfo' => $this->auth->getUserinfo()]);
        }
        $this->error($this->auth->getError());
    }

    /**
     * 手机验证码登录
     * @ApiMethod (POST)
     */
    public function mobilelogin()
    {
        $mobile = $this->request->post('mobile');
        $captcha = $this->request->post('captcha', $this->request->post('code'));
        if (!$mobile || !$captcha) {
            $this->error('参数不正确');
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error('手机号格式不正确');
        }
        if (!$this->checkSms($mobile, $captcha, 'mobilelogin')) {
            $this->error('验证码错误');
        }
        $user = \app\common\model\User::getByMobile($mobile);
        if (!$user) {
            $this->error('该手机号未注册');
        }
        if ($user->status != 'normal') {
            $this->error('账号已被锁定');
        }
        $ret = $this->auth->direct($user->id);
        if ($ret) {
            Sms::flush($mobile, 'mobilelogin');
            $this->success('登录成功', ['userinfo' => $this->auth->getUserinfo()]);
        }
        $this->error($this->auth->getError());
    }

    /**
     * 注册（mobile 手机号 + password 密码 + captcha 短信码 + invite_code 邀请码）
     * @ApiMethod (POST)
     */
    public function register()
    {
        $mobile = $this->request->post('mobile');
        $password = $this->request->post('password');
        $captcha = $this->request->post('captcha', $this->request->post('code'));
        $nickname = $this->request->post('nickname');
        $inviteCode = $this->request->post('invite_code', $this->request->post('pcode'));

        if (!$mobile || !$password) {
            $this->error('参数不正确');
        }
        if (!$inviteCode) {
            $this->error('请传入邀请码');
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error('手机号格式不正确');
        }
        // 短信验证码：与示例站一致，注册仅需邀请码即可；如填写了验证码则进行校验
        if ($captcha !== null && $captcha !== '') {
            if (!$this->checkSms($mobile, $captcha, 'register')) {
                $this->error('验证码错误');
            }
        }
        // 邀请人
        $parent = Db::name('user')->where('invite_code', $inviteCode)->find();
        if (!$parent) {
            $this->error('邀请码无效');
        }
        if (\app\common\model\User::getByMobile($mobile)) {
            $this->error('该手机号已注册');
        }
        // 用手机号作为用户名注册
        $ret = $this->auth->register($mobile, $password, '', $mobile, []);
        if (!$ret) {
            $this->error($this->auth->getError());
        }
        $user = $this->auth->getUser();
        // 生成本人邀请码（确保唯一）
        do {
            $newCode = Random::alnum(6);
        } while (Db::name('user')->where('invite_code', $newCode)->find());
        $teamPath = $parent['team_path'] ? $parent['team_path'] . ',' . $parent['id'] : (string) $parent['id'];
        $update = [
            'pid'         => $parent['id'],
            'invite_code' => $newCode,
            'team_path'   => $teamPath,
            'level'       => 1,
        ];
        if ($nickname !== null && $nickname !== '') {
            $update['nickname'] = $nickname;
        }
        Db::name('user')->where('id', $user->id)->update($update);
        // 新会员加入后，自下而上重新计算上级团队等级（经销商→经理→老板）
        \app\common\library\TeamService::recalcChain($user->id);
        Sms::flush($mobile, 'register');
        $this->success('注册成功', ['userinfo' => $this->auth->getUserinfo()]);
    }

    /**
     * 重置密码（mobile + captcha + newpassword）
     * @ApiMethod (POST)
     */
    public function resetpwd()
    {
        $mobile = $this->request->post('mobile');
        $captcha = $this->request->post('captcha', $this->request->post('code'));
        $newpassword = $this->request->post('newpassword', $this->request->post('password'));
        if (!$mobile || !$captcha || !$newpassword) {
            $this->error('参数不正确');
        }
        if (!Validate::regex($mobile, "^1\d{10}$")) {
            $this->error('手机号格式不正确');
        }
        $user = \app\common\model\User::getByMobile($mobile);
        if (!$user) {
            $this->error('该手机号未注册');
        }
        if (!$this->checkSms($mobile, $captcha, 'resetpwd')) {
            $this->error('验证码错误');
        }
        Sms::flush($mobile, 'resetpwd');
        $this->auth->direct($user->id);
        if ($this->auth->changepwd($newpassword, '', true)) {
            $this->success('密码重置成功');
        }
        $this->error($this->auth->getError());
    }

    /**
     * 退出登录
     */
    public function logout()
    {
        $this->auth->logout();
        $this->success('退出成功');
    }

    /**
     * 会员中心首页数据
     */
    public function index()
    {
        $user = $this->auth->getUser();
        $volumeCount = Db::name('user_coupon')->where('user_id', $user->id)->where('status', 0)->count();
        // 团队分组统计（各等级人数）
        $stat = \app\common\library\TeamService::groupStat($user->id);
        $data = [
            'nickname'          => $user->nickname,
            'id'                => $user->id,
            'mobile'            => $user->mobile,
            'avatar'            => $user->avatar ? cdnurl($user->avatar, true) : '',
            'money'             => $user->money,
            // 优惠券 = 后台「会员管理 → 优惠券余额(money)」的值，可在后台手动修改，前端实时一致。
            //   （兑换区抵扣/提现会扣减该余额；后台改多少前端就显示多少）
            'coupon'            => (float) $user->money,
            'is_team'           => $user->is_team,
            'is_takeEffect'     => $user->is_takeEffect,
            'group_id'          => $user->group_id,
            'volume_count'      => $volumeCount,
            'openid'            => 0,
            'level'             => $user->level,
            'level_name'        => \app\common\library\TeamService::levelName($user->level),
            // 直推普通会员数 / 直推经理数（兼容示例站字段）
            'normal_user_count' => Db::name('user')->where('pid', $user->id)->where('level', '<', 2)->count(),
            'manager_count'     => Db::name('user')->where('pid', $user->id)->where('level', '>=', 2)->count(),
            // 团队分组统计
            'team_total'        => $stat['total'],
            'distributor_count' => $stat['distributor'],
            'manager_total'     => $stat['manager'],
            'boss_count'        => $stat['boss'],
            'direct_count'      => $stat['direct'],
        ];
        $this->success('success', $data);
    }

    /**
     * 修改个人资料（昵称/头像）
     * @ApiMethod (POST)
     */
    public function profile()
    {
        $user = $this->auth->getUser();
        $nickname = $this->request->post('nickname');
        $avatar = $this->request->post('avatar');
        $update = [];
        if ($nickname !== null && $nickname !== '') {
            $update['nickname'] = mb_substr(trim((string) $nickname), 0, 20);
        }
        if ($avatar !== null && $avatar !== '') {
            // 仅保存相对路径，去掉域名前缀
            $update['avatar'] = preg_replace('#^https?://[^/]+#', '', (string) $avatar);
        }
        if (!$update) {
            $this->success('保存成功');
        }
        try {
            $update['updatetime'] = time();
            Db::name('user')->where('id', $user->id)->update($update);
        } catch (\Exception $e) {
            $this->error('保存失败：' . $e->getMessage());
        }
        $this->success('保存成功');
    }

    /**
     * 我的收益明细
     */
    public function profit()
    {
        list($page, $pageSize) = $this->getPage();
        $uid = $this->auth->id;
        $type = $this->request->request('type');
        // 「我的利润」不再展示团队分润(type=2)——该功能已下线（兼容历史遗留记录不显示）
        $query = Db::name('profit_log')->where('user_id', $uid)->where('type', '<>', 2);
        if ($type !== null && $type !== '') {
            $query->where('type', (int) $type);
        }
        $res = $query->order('id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $list = $res->items();
        // 我的利润余额：优先取后台可维护的 fa_user.profit（成交/分润会自动累加，后台亦可手动修改）
        $userRow = Db::name('user')->where('id', $uid)->field('profit')->find();
        $profit = ($userRow && $userRow['profit'] !== null)
            ? (float) $userRow['profit']
            : (float) Db::name('profit_log')->where('user_id', $uid)->sum('money');
        $this->success('success', [
            'list'      => $list,
            'total'     => $res->total(),
            'last_page' => $res->lastPage(),
            'profit'    => round($profit, 2),
        ]);
    }

    /**
     * 资金流水（收入/支出）
     */
    public function getMoneyList()
    {
        list($page, $pageSize) = $this->getPage();
        $uid = $this->auth->id;
        $res = Db::name('user_money_log')->where('user_id', $uid)
            ->order('id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $list = $res->items();
        $increase = Db::name('user_money_log')->where('user_id', $uid)->where('money', '>', 0)->sum('money');
        $reduce = Db::name('user_money_log')->where('user_id', $uid)->where('money', '<', 0)->sum('money');
        $this->success('success', [
            'list'      => $list,
            'total'     => $res->total(),
            'increase'  => round($increase, 2),
            'reduce'    => round(abs($reduce), 2),
            'last_page' => $res->lastPage(),
        ]);
    }

    /**
     * 收款记录（作为卖家已确认的订单）
     */
    public function collectionLog()
    {
        list($page, $pageSize) = $this->getPage();
        $uid = $this->auth->id;
        $res = Db::name('order')->where('seller_id', $uid)->where('pay_status', 2)
            ->order('id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $this->success('success', ['list' => $res->items(), 'total' => $res->total(), 'last_page' => $res->lastPage()]);
    }

    /**
     * 付款记录（作为买家的订单）
     */
    public function paymentLog()
    {
        list($page, $pageSize) = $this->getPage();
        $uid = $this->auth->id;
        $res = Db::name('order')->where('buyer_id', $uid)
            ->order('id desc')->paginate(['list_rows' => $pageSize, 'page' => $page]);
        $this->success('success', ['list' => $res->items(), 'total' => $res->total(), 'last_page' => $res->lastPage()]);
    }

    /**
     * 获取邀请链接
     */
    public function getInvitationLink()
    {
        $user = $this->auth->getUser();
        if (!$user->invite_code) {
            // 兜底：老用户没有邀请码时补一个
            do {
                $newCode = Random::alnum(6);
            } while (Db::name('user')->where('invite_code', $newCode)->find());
            Db::name('user')->where('id', $user->id)->update(['invite_code' => $newCode]);
            $user->invite_code = $newCode;
        }
        $domain = $this->request->domain();
        $url = $domain . '/h5/index.html#/pages/auth/register?code=' . $user->invite_code;
        $this->success('success', ['url' => $url, 'invite_code' => $user->invite_code]);
    }

    /**
     * 签约中心协议/合同文章（后台「配置」可设置 signing_doc1 / signing_doc2 资讯ID）
     * 返回可点击查看的文章标题列表：[{id,title}]，文章内容在「资讯管理」维护。
     */
    public function signingDocs()
    {
        $ids = [];
        foreach (['signing_doc1', 'signing_doc2'] as $k) {
            $v = (int) Db::name('config')->where('name', $k)->value('value');
            if ($v > 0) {
                $ids[] = $v;
            }
        }
        $docs = [];
        if ($ids) {
            $rows = Db::name('news')->whereIn('id', $ids)->where('status', 1)->column('title', 'id');
            foreach ($ids as $id) {
                if (isset($rows[$id])) {
                    $docs[] = ['id' => $id, 'title' => $rows[$id]];
                }
            }
        }
        $this->success('success', $docs);
    }

    /**
     * 获取签约信息
     */
    public function getSigningAContract()
    {
        $info = Db::name('signing')->where('user_id', $this->auth->id)->order('id desc')->find();
        if ($info && $info['image']) {
            $info['image'] = cdnurl($info['image'], true);
        }
        $this->success('success', $info ?: null);
    }

    /**
     * 提交签约（GET 提交，与示例站一致）
     */
    public function signingAContract()
    {
        $uid = $this->auth->id;
        $name = $this->request->request('name');
        $image = $this->request->request('image');
        $cardName = $this->request->request('card_name');
        $cardNo = $this->request->request('card_no');
        $cardLine = $this->request->request('card_line');
        $cardBranch = $this->request->request('card_branch');
        if (!$name && !$image) {
            $this->error('请完善签约信息');
        }
        $data = [
            'user_id'     => $uid,
            'name'        => $name ?: '',
            'image'       => $image ? preg_replace('#^https?://[^/]+#', '', $image) : '',
            'card_name'   => $cardName ?: '',
            'card_no'     => $cardNo ?: '',
            'card_line'   => $cardLine ?: '',
            'card_branch' => $cardBranch ?: '',
            'status'      => 0,
            'updatetime'  => time(),
        ];
        $exist = Db::name('signing')->where('user_id', $uid)->find();
        if ($exist) {
            Db::name('signing')->where('id', $exist['id'])->update($data);
        } else {
            $data['createtime'] = time();
            Db::name('signing')->insert($data);
        }
        $this->success('提交成功');
    }
}

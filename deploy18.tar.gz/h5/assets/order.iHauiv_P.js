const s="/h5/static/icons/order.svg";export{s as _};

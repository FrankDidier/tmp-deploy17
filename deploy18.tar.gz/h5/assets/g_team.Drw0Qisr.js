const s="/h5/static/icons/g_team.svg";export{s as _};

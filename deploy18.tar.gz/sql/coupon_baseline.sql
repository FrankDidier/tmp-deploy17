-- 20260717 优惠券钱包「基准重算」（甲方选项C，一次性执行；可重复执行，结果一致）
-- 规则：优惠券余额(fa_user.money) = 本人「已确认收款」的抢购单金额合计 × 优惠券比例(coupon_rate%) − 已兑换消耗(fa_redeem_log.cost)
-- 之后：抢购成交(确认收款)自动按比例返券累加(OrderService::settle)，后台可手动增减，兑换/提现扣减；前端显示该余额。
-- 注意：本脚本会「覆盖」现有 money 值（把优惠券余额重置为公式基准）。卖家成交收益已改为只进「我的利润(profit)」，不再进 money。

SET @rate := (SELECT COALESCE(NULLIF(`value`, ''), '0.5') FROM `fa_config` WHERE `name` = 'coupon_rate' LIMIT 1);

UPDATE `fa_user` u
LEFT JOIN (
    SELECT `buyer_id` AS uid, SUM(`amount`) AS amt
    FROM `fa_order`
    WHERE `buyer_id` > 0 AND `type` IN (1, 2) AND `pay_status` = 2 AND (`pay_kind` IS NULL OR `pay_kind` <> 2)
    GROUP BY `buyer_id`
) g ON g.uid = u.id
LEFT JOIN (
    SELECT `user_id` AS uid, SUM(`cost`) AS c
    FROM `fa_redeem_log`
    WHERE `status` IN (0, 1)
    GROUP BY `user_id`
) r ON r.uid = u.id
SET u.`money` = GREATEST(0, ROUND(COALESCE(g.amt, 0) * (@rate + 0) / 100, 2) - COALESCE(r.c, 0));

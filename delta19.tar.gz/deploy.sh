#!/bin/bash
# 本轮更新部署脚本（宝塔计划任务执行）
# 本轮改动仅在 后端 application/ 与 前端 H5，无需数据库迁移。
# 用法：bash deploy.sh [webroot]   默认 mall.feiyunkeji.cn；mall3 传入其站点根目录。
ROOT=${1:-/www/wwwroot/mall.feiyunkeji.cn}
PKG=$(cd "$(dirname "$0")" && pwd)
LOG=$ROOT/deploy_update.log

exec >"$LOG" 2>&1
echo "=== DEPLOY START $(date) ==="
echo "PKG=$PKG ROOT=$ROOT"

# 0) 先清理 macOS 隐藏文件，避免 ThinkPHP 误 include 导致白屏/乱码
find "$PKG" -name '._*' -delete 2>/dev/null || true
find "$PKG" -name '.DS_Store' -delete 2>/dev/null || true

# 1) 后端 application（本轮全部改动：upload.php / 会员导入 / 指派会员下拉视图）
cp -rf "$PKG/backend/application/." "$ROOT/application/" && echo "-- application copied"

# 2) H5（未登录守卫 / 重新编译）
mkdir -p "$ROOT/public/h5"
find "$ROOT/public/h5" -mindepth 1 -delete 2>/dev/null || true
cp -rf "$PKG/h5/." "$ROOT/public/h5/" && echo "-- h5 deployed to public/h5"

# 3) 再次清理隐藏文件（部署目标目录）
find "$ROOT/application" "$ROOT/public/h5" -name '._*' -delete 2>/dev/null || true

# 4) 清理 ThinkPHP 缓存
rm -rf "$ROOT/runtime/cache/"* "$ROOT/runtime/temp/"* 2>/dev/null || true
echo "-- runtime cache cleared"

echo "DEPLOY_OK $(date)"

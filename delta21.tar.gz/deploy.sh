#!/bin/bash
# delta20 部署：修复「指派用户」下拉（selectpage 全部会员 + 手机号模糊搜索）
# 改动文件：application/admin/controller/subarea/Goods.php 与 public/assets/js/backend/subarea/goods.js
ROOT=${1:-/www/wwwroot/mall.feiyunkeji.cn}
PKG=$(cd "$(dirname "$0")" && pwd)
LOG=$ROOT/deploy_update.log

exec >"$LOG" 2>&1
echo "=== DEPLOY START $(date) ==="
echo "PKG=$PKG ROOT=$ROOT"

find "$PKG" -name '._*' -delete 2>/dev/null || true
find "$PKG" -name '.DS_Store' -delete 2>/dev/null || true

# 1) 后端 application（含 subarea/Goods.php）
cp -rf "$PKG/backend/application/." "$ROOT/application/" && echo "-- application copied"

# 2) 后台静态资源 js（含 subarea/goods.js）
cp -rf "$PKG/backend/public/." "$ROOT/public/" && echo "-- public assets copied"

find "$ROOT/application" "$ROOT/public/assets/js/backend/subarea" -name '._*' -delete 2>/dev/null || true

# 3) 清理 ThinkPHP 缓存
rm -rf "$ROOT/runtime/cache/"* "$ROOT/runtime/temp/"* 2>/dev/null || true
echo "-- runtime cache cleared"

echo "DEPLOY_OK $(date)"
